# -*- coding: utf-8 -*-
"""
LearnLume Studio - the window where you drop PDFs and get a study app.
Runs only on this computer (127.0.0.1), no internet needed after setup.
"""
import json, os, re, subprocess, sys, threading, time, urllib.parse, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))
JOBS = os.path.join(HERE, "jobs")
PORT = 8740
RUNNING = {}

# rough speed of a small model on a normal CPU, measured on a 12-thread laptop (tokens per second)
GEN_TPS, PROMPT_TPS = 6.5, 37.0


def slug(s):
    s = re.sub(r"[^\w֐-׿\- ]+", "", s, flags=re.U).strip().replace(" ", "-")
    return (s or "course")[:40] + "-" + time.strftime("%m%d%H%M%S")


def safe_name(n):
    n = os.path.basename(urllib.parse.unquote(n)).replace("..", "")
    return re.sub(r'[<>:"/\\|?*]', "_", n)[:150] or "file.pdf"


def extract_pdfs(data, low, dest):
    """take only the PDF files out of a zip / tar archive (no paths, no other files)"""
    import io, tarfile, zipfile
    names = []

    def put(fname, blob):
        n = safe_name(fname)
        base, i = n, 1
        while os.path.exists(os.path.join(dest, n)):
            n = f"{os.path.splitext(base)[0]}_{i}.pdf"
            i += 1
        with open(os.path.join(dest, n), "wb") as f:
            f.write(blob)
        names.append(n)
    if low.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                if info.filename.lower().endswith(".pdf") and not info.is_dir() and info.file_size < 300 * 2**20:
                    put(info.filename, z.read(info))
    else:
        with tarfile.open(fileobj=io.BytesIO(data)) as t:
            for m in t.getmembers():
                if m.isfile() and m.name.lower().endswith(".pdf") and m.size < 300 * 2**20:
                    put(m.name, t.extractfile(m).read())
    return names


def job_info(jid):
    d = os.path.join(JOBS, jid)
    meta = {}
    try:
        meta = json.load(open(os.path.join(d, "job.json"), encoding="utf-8"))
    except Exception:
        pass
    prog = {}
    try:
        prog = json.load(open(os.path.join(d, "output", "progress.json"), encoding="utf-8"))
    except Exception:
        pass
    inp = os.path.join(d, "input")
    files = sorted(os.listdir(inp)) if os.path.isdir(inp) else []
    err = ""
    ep = os.path.join(d, "output", "error.txt")
    if os.path.exists(ep):
        err = open(ep, encoding="utf-8").read()[-1500:]
    running = jid in RUNNING and RUNNING[jid].poll() is None
    state = prog.get("state") or ("new" if not prog else "stopped")
    if state == "running" and not running:
        state = "stopped"
    return {"id": jid, **meta, "files": files, "progress": prog, "state": state, "running": running, "error": err,
            "has_app": os.path.exists(os.path.join(d, "output", "index.html"))}


def estimate(jid, mode):
    """minutes, from the page count and the measured speed"""
    try:
        import pymupdf
    except Exception:
        return None
    inp = os.path.join(JOBS, jid, "input")
    pages = exams = 0
    for f in os.listdir(inp):
        if f.lower().endswith(".pdf"):
            try:
                n = len(pymupdf.open(os.path.join(inp, f)))
            except Exception:
                continue
            pages += n
            if re.search(r"exam|בחינ|מבחן", f.lower()):
                exams += 1
    units = min(14 if mode == "full" else 6, max(3, pages // 25))
    per_unit_pages = 8 if mode == "full" else 4
    calls_tokens = units * (per_unit_pages / 2 * 700 + 1500 + (2 if mode == "full" else 1) * 2000 + (8 if mode == "full" else 4) * (2 * 200 + 120) + (1200 if mode == "full" else 600) + 900 + 900)
    ex = min(exams, 5 if mode == "full" else 2) * 6 * 900
    gen = (calls_tokens + ex) * 1.25  # translation and retries
    prompt = gen * 3
    ocr = min(pages, units * per_unit_pages + min(exams, 5 if mode == "full" else 2) * 15) * 0.5 * (900 / GEN_TPS + 1100 / PROMPT_TPS)
    minutes = (gen / GEN_TPS + prompt / PROMPT_TPS + ocr) / 60
    return {"pages": pages, "units": units, "minutes": round(minutes)}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def q(self):
        return dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))

    def body(self):
        n = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(n) if n else b""

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self.send(200, open(os.path.join(HERE, "studio.html"), "rb").read(), "text/html; charset=utf-8")
        if path == "/api/jobs":
            ids = sorted(os.listdir(JOBS), reverse=True) if os.path.isdir(JOBS) else []
            return self.send(200, [job_info(j) for j in ids if os.path.isdir(os.path.join(JOBS, j))])
        if path == "/api/job":
            return self.send(200, job_info(self.q()["job"]))
        if path == "/api/estimate":
            q = self.q()
            return self.send(200, estimate(q["job"], q.get("mode", "full")) or {})
        if path.startswith("/jobs/"):  # serve the built apps
            rel = urllib.parse.unquote(path[len("/jobs/"):])
            full = os.path.normpath(os.path.join(JOBS, rel))
            if not full.startswith(os.path.normpath(JOBS)) or not os.path.isfile(full):
                return self.send(404, "not found", "text/plain")
            ext = os.path.splitext(full)[1].lower()
            ctype = {".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".mp4": "video/mp4",
                     ".woff2": "font/woff2", ".json": "application/json", ".png": "image/png"}.get(ext, "application/octet-stream")
            return self.send(200, open(full, "rb").read(), ctype)
        self.send(404, "not found", "text/plain")

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/new":
            data = json.loads(self.body() or b"{}")
            jid = slug(data.get("name") or "course")
            os.makedirs(os.path.join(JOBS, jid, "input"), exist_ok=True)
            json.dump({"name": data.get("name") or "My course", "langs": data.get("langs") or ["he"],
                       "mode": data.get("mode") or "full", "created": time.strftime("%Y-%m-%d %H:%M")},
                      open(os.path.join(JOBS, jid, "job.json"), "w", encoding="utf-8"), ensure_ascii=False)
            return self.send(200, {"id": jid})
        if path == "/api/settings":
            q = self.q()
            data = json.loads(self.body() or b"{}")
            p = os.path.join(JOBS, q["job"], "job.json")
            meta = json.load(open(p, encoding="utf-8"))
            meta.update({k: v for k, v in data.items() if k in ("name", "langs", "mode")})
            json.dump(meta, open(p, "w", encoding="utf-8"), ensure_ascii=False)
            return self.send(200, {"ok": True})
        if path == "/api/start":
            jid = self.q()["job"]
            if jid in RUNNING and RUNNING[jid].poll() is None:
                return self.send(200, {"ok": True, "already": True})
            meta = json.load(open(os.path.join(JOBS, jid, "job.json"), encoding="utf-8"))
            args = [sys.executable, os.path.join(HERE, "learnlume.py"), "--job", os.path.join(JOBS, jid),
                    "--name", meta["name"], "--langs", ",".join(meta["langs"]), "--mode", meta["mode"], "--no-browser"]
            if os.environ.get("LEARNLUME_MOCK"):
                args.append("--mock")
            log = open(os.path.join(JOBS, jid, "build.log"), "w", encoding="utf-8")
            RUNNING[jid] = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, cwd=HERE,
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return self.send(200, {"ok": True})
        if path == "/api/stop":
            jid = self.q()["job"]
            p = RUNNING.get(jid)
            if p and p.poll() is None:
                p.terminate()
            return self.send(200, {"ok": True})
        if path == "/api/folder":
            d = os.path.join(JOBS, self.q()["job"], "output")
            if hasattr(os, "startfile") and os.path.isdir(d):
                os.startfile(d)
            return self.send(200, {"ok": True})
        self.send(404, {"error": "unknown"})

    def do_PUT(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/upload":
            q = self.q()
            name = safe_name(q["name"])
            low = name.lower()
            d = os.path.join(JOBS, q["job"], "input")
            os.makedirs(d, exist_ok=True)
            data = self.body()
            if low.endswith(".pdf"):
                with open(os.path.join(d, name), "wb") as f:
                    f.write(data)
                return self.send(200, {"ok": True, "names": [name]})
            if low.endswith((".zip", ".tar", ".tar.gz", ".tgz")):
                return self.send(200, {"ok": True, "names": extract_pdfs(data, low, d)})
            return self.send(400, {"error": "PDF / ZIP / TAR only"})
        self.send(404, {"error": "unknown"})


def main():
    os.makedirs(JOBS, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    url = f"http://127.0.0.1:{PORT}/"
    print(f"LearnLume Studio is running: {url}\nKeep this window open while LearnLume works. Close it to stop.")
    if "--no-browser" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
