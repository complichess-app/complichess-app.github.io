# -*- coding: utf-8 -*-
"""
LearnLume 0.4.0 - study-app generator (Claude writes, the app runs offline).
Copyright (c) 2026 Bar Lvovski. All rights reserved.

  PDFs of a course  ->  ADHD-friendly study app (like "בדידה מאפס"), fully offline.

Two ways to write the app:
  api      the Claude API with the user's own key (default when a key is saved): fast, best text
  local    a small model on this computer through llama.cpp (downloads ~7 GB once, slow, no internet after)

Engine stages:
  setup    api: check the Claude key / local: download llama.cpp + models once (resumable)
  ingest   read every PDF, classify (book / notes / assignment / solution / exam), score broken text
  plan     find the course units (book tables of contents + syllabus + headings)
  ocr      pages whose text came out broken (math symbols lost etc.) are read again from the page image
  notes    per unit: faithful study notes from the material (map -> reduce)
  lessons  from-zero lesson per unit, colour/shape coded blocks
  questions + verify   multiple choice, every answer checked by majority vote + independent python check
  worked   worked examples taken from the course's own solved exercises
  exams    past exams split into questions, explained from the OFFICIAL solution when it exists
  recipes  exam recipe book per unit (how it appears in the exam + fill-in template)
  extras   exam-day strategy (from the real exam cover page) + printable cheat sheet
  translate  into every requested language
  build    single offline app folder (index.html + vendor/katex + videos)

Run:  python learnlume.py --job jobs/my-course --name "Discrete math" --langs he
      python learnlume.py --job ... --backend local   (the local model instead of the Claude API)
      python learnlume.py --job ... --mock            (no model at all: tests the whole pipeline)
"""
import argparse, base64, collections, concurrent.futures, html, json, math, os, random, re, shutil, socket, subprocess, sys, threading, time, zipfile
import urllib.error, urllib.parse, urllib.request

VERSION = "0.4.0"
HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, "tools")
MODELS_DIR = os.path.join(HERE, "models")
PORT = 8737  # the local model server
LANG_NAMES = {"he": "Hebrew", "en": "English", "ar": "Arabic", "ru": "Russian", "es": "Spanish", "fr": "French"}

MODES = {  # quick = first look in ~1/3 of the time, full = best quality
    "quick": {"max_units": 6, "pages_per_unit": 6, "q_rounds": 1, "votes": 3, "max_exams": 2, "worked": 2, "ocr": 0.45, "dpi": 130},
    "full": {"max_units": 14, "pages_per_unit": 14, "q_rounds": 2, "votes": 3, "max_exams": 6, "worked": 3, "ocr": 0.25, "dpi": 150},
}
MODES_LOCAL = {  # a small model on a CPU: less text per call, fewer pages (the 0.3 settings)
    "quick": {"max_units": 6, "pages_per_unit": 4, "q_rounds": 1, "votes": 3, "max_exams": 1, "worked": 1, "ocr": 0.55, "dpi": 110},
    "full": {"max_units": 14, "pages_per_unit": 8, "q_rounds": 2, "votes": 3, "max_exams": 5, "worked": 3, "ocr": 0.30, "dpi": 130},
}

# ======================================================================= settings (kept outside the app folder)
# The Claude key and the chosen backend live in the user's profile (%APPDATA%\LearnLume), so a new version of the
# folder keeps them and the key never ends up in a zip, a job folder or a log.
CONF_DIR = os.environ.get("LEARNLUME_HOME") or os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "LearnLume")
KEY_FILE = os.path.join(CONF_DIR, "claude-key.txt")
SETTINGS_FILE = os.path.join(CONF_DIR, "settings.json")
LEGACY_KEY = os.path.join(HERE, "key.txt")  # where 0.3.x kept it
KEY_RE = re.compile(r"sk-ant-[\w-]{20,}")


def load_settings():
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            s = json.load(f)
        return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def save_settings(**kw):
    s = load_settings()
    s.update({k: v for k, v in kw.items() if v is not None})
    for k in [k for k, v in kw.items() if v is None]:
        s.pop(k, None)
    os.makedirs(CONF_DIR, exist_ok=True)
    tmp = SETTINGS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=1)
    os.replace(tmp, SETTINGS_FILE)
    return s


def key_source():
    """(key, where): the saved key first, then a 0.3.x key.txt, then ANTHROPIC_API_KEY"""
    for where, p in (("saved", KEY_FILE), ("legacy", LEGACY_KEY)):
        try:
            with open(p, encoding="utf-8") as f:
                k = f.read().strip()
            if k:
                return k, where
        except OSError:
            pass
    k = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    return (k, "env") if k else ("", "")


def api_key():
    return key_source()[0]


def save_key(k):
    os.makedirs(CONF_DIR, exist_ok=True)
    fd = os.open(KEY_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(k)
    if os.path.exists(LEGACY_KEY):
        os.remove(LEGACY_KEY)  # one place only


def remove_key():
    for p in (KEY_FILE, LEGACY_KEY):
        if os.path.exists(p):
            os.remove(p)


def backend_choice(arg=None):
    b = arg or load_settings().get("backend") or "api"
    return b if b in ("api", "local") else "api"


# ======================================================================= progress
STAGES = [
    ("setup", 1, "חיבור ל-Claude", "Connecting to Claude"),
    ("ingest", 2, "קריאת קבצי ה-PDF", "Reading the PDFs"),
    ("plan", 3, "זיהוי נושאי הקורס", "Finding the course topics"),
    ("ocr", 18, "קריאה חכמה של עמודים שבורים", "Re-reading broken pages"),
    ("notes", 11, "סיכומים מתוך החומר", "Notes from the material"),
    ("lessons", 10, "כתיבת שיעורים מאפס", "Writing from-zero lessons"),
    ("questions", 8, "יצירת שאלות", "Creating questions"),
    ("verify", 14, "בדיקת כל תשובה", "Checking every answer"),
    ("worked", 4, "פתרונות מודרכים", "Worked examples"),
    ("exams", 12, "בחינות עבר עם פתרון", "Past exams with solutions"),
    ("recipes", 3, "ספר מתכונים לבחינה", "Exam recipe book"),
    ("extras", 1, "אסטרטגיה ודף עזר", "Strategy and cheat sheet"),
    ("cards", 2, "כרטיסיות", "Flashcards"),
    ("translate", 6, "תרגום", "Translating"),
    ("build", 1, "בניית האפליקציה", "Building the app"),
]
STAGES_LOCAL = [("setup", 5, "הכנה: כלים ומודלים (פעם אחת)", "Setup: tools and models (once)")] + STAGES[1:]


class Progress:
    def __init__(self, out_dir, title, stages=STAGES):
        self.out, self.title = out_dir, title
        self.stages = stages
        self.total_w = sum(s[1] for s in stages)
        self.t0 = time.time()
        self.stage, self.frac, self.note = None, 0.0, ""
        self.log = []
        self.state = "running"
        os.makedirs(out_dir, exist_ok=True)

    def pct(self):
        if self.stage == "done":
            return 100.0
        done = 0
        for k, w, *_ in self.stages:
            if k == self.stage:
                return (done + w * self.frac) / self.total_w * 100
            done += w
        return 0.0

    def label(self, stage, lang=0):
        for k, w, he, en in self.stages:
            if k == stage:
                return (he, en)[lang]
        return ("הסתיים!", "Done!")[lang] if stage == "done" else str(stage)

    def set(self, stage, frac=0.0, note=""):
        if stage != self.stage:
            self.log.append(f"{time.strftime('%H:%M:%S')}  {self.label(stage)}")
        self.stage, self.frac, self.note = stage, max(0.0, min(1.0, frac)), note
        self.write()

    def eta_min(self):
        p = self.pct()
        if p < 2:
            return None
        return (time.time() - self.t0) * (100 - p) / p / 60

    def write(self):
        p = self.pct()
        eta = self.eta_min()
        bar = "#" * int(p / 2.5) + "-" * (40 - int(p / 2.5))
        e = "ETA ..." if eta is None else f"ETA {int(eta // 60)}h{int(eta % 60):02d}m"
        try:
            sys.stdout.write(f"\r[{bar}] {p:5.1f}%  {str(self.stage):<9} {e:<12}")
            sys.stdout.flush()
        except Exception:
            pass
        data = {"percent": round(p, 1), "stage": self.stage, "label": self.label(self.stage),
                "label_en": self.label(self.stage, 1), "note": self.note, "state": self.state,
                "eta_min": None if eta is None else round(eta, 1),
                "elapsed_min": round((time.time() - self.t0) / 60, 1), "log": self.log[-14:], "title": self.title}
        try:
            tmp = os.path.join(self.out, "progress.json.tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp, os.path.join(self.out, "progress.json"))
            self.write_html(data)
        except Exception:
            pass

    def write_html(self, d):
        refresh = '<meta http-equiv="refresh" content="3">' if self.state == "running" else ""
        eta = "מחשב..." if d["eta_min"] is None else (
            f"{int(d['eta_min'] // 60)} שעות {int(d['eta_min'] % 60)} דק'" if d["eta_min"] >= 60 else f"{int(d['eta_min'])} דק'")
        logs = "".join(f"<li>{html.escape(x)}</li>" for x in d["log"])
        page = f"""<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8">{refresh}
<title>LearnLume · {d['percent']:.0f}%</title><style>
body{{font-family:Segoe UI,Arial,sans-serif;background:#14182B;color:#fff;margin:0;padding:40px}}
.card{{max-width:720px;margin:auto;background:#1E2440;border-radius:20px;padding:32px}}
.bar{{height:28px;background:#2E3450;border-radius:14px;overflow:hidden;margin:18px 0}}
.fill{{height:100%;width:{d['percent']:.1f}%;background:linear-gradient(90deg,#57CC99,#4EA8DE)}}
.big{{font-size:56px;font-weight:700;color:#57CC99}} .muted{{color:#9AA3C2}} li{{margin:4px 0}}
a{{color:#57CC99}}</style></head><body><div class="card">
<div class="muted">LearnLume בונה: {html.escape(self.title)}</div>
<div class="big">{d['percent']:.1f}%</div><div class="bar"><div class="fill"></div></div>
<div><b>{html.escape(d['label'])}</b> <span class="muted">{html.escape(d['note'])}</span></div>
<p class="muted">זמן שעבר: {d['elapsed_min']} דק' · נשאר בערך: {html.escape(eta)}</p>
{'<p><a href="index.html">פתיחת האפליקציה ←</a></p>' if self.state == "done" else ''}
<ul class="muted">{logs}</ul><p class="muted">אפשר להשאיר את המחשב לעבוד. אם הוא כבה, מריצים שוב והבנייה ממשיכה מאיפה שעצרה.</p>
</div></body></html>"""
        with open(os.path.join(self.out, "progress.html"), "w", encoding="utf-8") as f:
            f.write(page)


class Cache:
    """every model answer is saved, so a crashed / stopped build resumes for free"""

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()  # answers arrive from several Claude calls at once
        self.d = {}
        if os.path.exists(path):
            try:
                self.d = json.load(open(path, encoding="utf-8"))
            except Exception:
                self.d = {}

    def get(self, k):
        return self.d.get(k)

    def put(self, k, v):
        with self.lock:
            self.d[k] = v
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.d, f, ensure_ascii=False)
            os.replace(tmp, self.path)


# ======================================================================= Claude API
# With the API backend Claude writes the app: nothing to download, much better text, and a build takes minutes
# instead of a day. Only what each step needs is sent: one unit's pages, one question, one exam question. The
# finished app never calls anything; it works offline. The key goes to api.anthropic.com and nowhere else.
API_URL = "https://api.anthropic.com/v1/messages"
_test_url = os.environ.get("LEARNLUME_API_URL", "")
if _test_url and urllib.parse.urlparse(_test_url).hostname in ("127.0.0.1", "localhost"):
    API_URL = _test_url  # a mock of the API on this computer, for tests only
API_VERSION = "2026-10-21"
MODEL_NAMES = {"claude-opus-5-5": "Claude Opus 5.5", "claude-sonnet-5-5": "Claude Sonnet 5.5", "claude-haiku-5-5": "Claude Haiku 5.5"}
PRESETS = {  # which Claude does which job (top: lessons, worked examples, exam explanations; mid: everything else;
    #          fast: the independent solvers that vote on every answer)
    "balanced": {"top": "claude-opus-5-5", "mid": "claude-sonnet-5-5", "fast": "claude-haiku-5-5"},
    "economy": {"top": "claude-sonnet-5-5", "mid": "claude-sonnet-5-5", "fast": "claude-haiku-5-5"},
    "best": {"top": "claude-opus-5-5", "mid": "claude-opus-5-5", "fast": "claude-sonnet-5-5"},
}
DEFAULT_PRESET = "balanced"
EFFORT = {"top": "high", "mid": "medium", "fast": "low"}  # how hard Claude thinks before it answers
PRICE = {"claude-opus-5-5": (4.0, 20.0), "claude-sonnet-5-5": (2.0, 10.0), "claude-haiku-5-5": (0.10, 0.50)}  # $ per M tokens
FALLBACK_MODELS = ("claude-opus-5-5", "claude-sonnet-5-5")  # if Claude declines a part, Anthropic retries it on another model
FALLBACK_BETA = "server-side-fallback-2026-07-01"
MAX_OUT = 64000


class ApiError(RuntimeError):
    """a problem the user can fix or wait out; `code` is what the Studio explains in the user's language"""

    def __init__(self, code, detail=""):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code, self.detail = code, detail


class StreamError(Exception):
    def __init__(self, etype, msg=""):
        super().__init__(f"{etype}: {msg}")
        self.etype = etype


def api_schema(s):
    """the schemas LearnLume uses -> what structured outputs accept (closed objects, no numeric/length limits;
    the limits go into the description so Claude still sees them, and fill_defaults() cleans up afterwards)"""
    s = dict(s)
    hint = []
    if "minItems" in s or "maxItems" in s:
        hint.append(f"{s.get('minItems', 0)} to {s['maxItems']} items" if "maxItems" in s else f"at least {s['minItems']} items")
    if "maxLength" in s:
        hint.append(f"at most {s['maxLength']} characters")
    if "minimum" in s or "maximum" in s:
        hint.append(f"from {s.get('minimum', '')} to {s.get('maximum', '')}".replace("from  ", "up ").strip())
    for k in ("minimum", "maximum", "minLength", "maxLength", "minItems", "maxItems"):
        s.pop(k, None)
    if "enum" in s and "type" not in s:
        s["type"] = "string"
    if s.get("type") == "object":
        s["properties"] = {k: api_schema(v) for k, v in s.get("properties", {}).items()}
        s["required"] = list(s["properties"])
        s["additionalProperties"] = False
    elif s.get("type") == "array":
        s["items"] = api_schema(s["items"])
    if hint:
        s["description"] = (s.get("description", "") + " " + "; ".join(hint)).strip()
    return s


def read_stream(lines):
    """server-sent events of a streamed Messages answer -> the finished message (content, stop_reason, usage)"""
    msg = {"content": [], "stop_reason": None, "usage": {}, "model": None}
    blocks, done = {}, False
    for raw in lines:
        line = raw.decode("utf-8", "replace").strip() if isinstance(raw, bytes) else raw.strip()
        if not line.startswith("data:"):
            continue
        try:
            ev = json.loads(line[5:])
        except ValueError:
            raise StreamError("incomplete", "unreadable event")
        t = ev.get("type")
        if t == "message_start":
            m = ev.get("message") or {}
            msg["model"] = m.get("model")
            msg["usage"].update(m.get("usage") or {})
        elif t == "content_block_start":
            blocks[ev.get("index", 0)] = dict(ev.get("content_block") or {})
        elif t == "content_block_delta":
            b = blocks.setdefault(ev.get("index", 0), {"type": "text", "text": ""})
            d = ev.get("delta") or {}
            if d.get("type") == "text_delta":
                b["text"] = b.get("text", "") + d.get("text", "")
        elif t == "message_delta":
            msg["stop_reason"] = (ev.get("delta") or {}).get("stop_reason") or msg["stop_reason"]
            msg["usage"].update({k: v for k, v in (ev.get("usage") or {}).items() if v is not None})
        elif t == "error":
            e = ev.get("error") or {}
            raise StreamError(e.get("type", "api_error"), e.get("message", ""))
        elif t == "message_stop":
            done = True
            break
    if not done:
        raise StreamError("incomplete", "the answer stopped in the middle")
    msg["content"] = [blocks[i] for i in sorted(blocks)]
    return msg


def error_info(e):
    try:
        err = json.loads(e.read().decode("utf-8", "replace")).get("error") or {}
        return err.get("type", ""), str(err.get("message", ""))[:300]
    except Exception:
        return "", ""


def retry_after(headers):
    try:
        return max(0.0, min(120.0, float(headers.get("retry-after"))))
    except (TypeError, ValueError):
        return None


class ClaudeLLM:
    """Same interface the builder always used (start/stop/chat), backed by the Claude API."""

    def __init__(self, work, mock=False, preset=DEFAULT_PRESET):
        self.work, self.mock = work, mock
        self.models = PRESETS.get(preset) or PRESETS[DEFAULT_PRESET]
        self.calls = 0
        self.gen_tokens = 0
        self.in_tokens = 0
        self.cost = 0.0
        self.key = "" if mock else api_key()
        self.lock = threading.Lock()
        self.fallbacks = True
        self.timeout = 300  # seconds of silence; a streamed answer sends a sign of life far more often
        self.on_wait = None

    def start(self, *a, **k):  # nothing to start: kept so the call sites are the same for both backends
        pass

    def stop(self):
        pass

    def _wait(self, sec):
        if self.on_wait:
            try:
                self.on_wait(sec)
            except Exception:
                pass
        time.sleep(sec)

    def _post(self, body, tries=6):
        """one streamed request; waits out rate limits, overload and short outages, raises ApiError otherwise"""
        data = json.dumps(body).encode("utf-8")
        headers = {"x-api-key": self.key, "anthropic-version": API_VERSION, "content-type": "application/json"}
        if "fallbacks" in body:
            headers["anthropic-beta"] = FALLBACK_BETA
        wait, last = 2.0, "network"
        for attempt in range(tries):
            req = urllib.request.Request(API_URL, data=data, headers=headers, method="POST")
            delay = None
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return read_stream(r)
            except urllib.error.HTTPError as e:
                etype, msg = error_info(e)
                if e.code == 401:
                    raise ApiError("auth", msg)
                if e.code == 402 or etype == "billing_error" or "credit balance" in msg.lower():
                    raise ApiError("billing", msg)
                if e.code == 403:
                    raise ApiError("permission", msg)
                if e.code == 404:
                    raise ApiError("model", msg)
                if e.code == 413:
                    raise ApiError("too_large", msg)
                if e.code in (400, 422):
                    raise ApiError("bad_request", msg)
                last = "rate" if e.code == 429 else "overloaded"  # 429, 500, 529 ...: wait and try again
                delay = retry_after(e.headers)
            except StreamError as e:
                last = "rate" if "rate_limit" in e.etype else "overloaded" if e.etype != "incomplete" else "network"
            except (socket.timeout, TimeoutError):
                last = "timeout"
            except (urllib.error.URLError, ConnectionError, OSError):
                last = "network"
            if attempt < tries - 1:
                self._wait(delay if delay is not None else wait + random.random())
                wait = min(wait * 2, 60)
        raise ApiError(last)

    def check_key(self, tries=6):
        if self.mock:
            return
        if not self.key:
            raise ApiError("no_key")
        self._post({"model": self.models["fast"], "max_tokens": 32, "stream": True, "output_config": {"effort": "low"},
                    "messages": [{"role": "user", "content": "Reply with OK."}]}, tries)

    @staticmethod
    def test_key(key):
        """one tiny request; returns "ok" or the error code (auth, billing, network ...)"""
        c = ClaudeLLM("", preset=DEFAULT_PRESET)
        c.key, c.timeout = key, 30
        try:
            c.check_key(tries=2)
            return "ok"
        except ApiError as e:
            return e.code

    def _count(self, model, u):
        pin, pout = PRICE.get(model, (0, 0))
        with self.lock:
            self.in_tokens += u.get("input_tokens", 0) or 0
            self.gen_tokens += u.get("output_tokens", 0) or 0
            self.cost += ((u.get("input_tokens", 0) or 0) * pin + (u.get("output_tokens", 0) or 0) * pout) / 1e6

    def chat(self, system, user, schema=None, temperature=0.3, max_tokens=1500, image_png=None, tier="mid"):
        # temperature is for the local model only: this API version samples with Claude's own settings
        with self.lock:
            self.calls += 1
        if self.mock:
            return mock_answer(schema, user, image_png is not None)
        model = self.models[tier]
        content = [{"type": "text", "text": user}]
        if image_png:
            content.insert(0, {"type": "image", "source": {"type": "base64", "media_type": "image/png",
                                                            "data": base64.b64encode(image_png).decode()}})
        # Claude thinks before it answers and that counts against max_tokens, so leave plenty of room;
        # only what is really written is paid for
        body = {"model": model, "max_tokens": min(MAX_OUT, max(16000, max_tokens * 4)), "stream": True, "system": system,
                "messages": [{"role": "user", "content": content}], "output_config": {"effort": EFFORT[tier]}}
        if schema:  # the answer is JSON that must match the schema
            body["output_config"]["format"] = {"type": "json_schema", "schema": api_schema(schema)}
        if model in FALLBACK_MODELS and self.fallbacks:
            body["fallbacks"] = "default"
        last, salvage = None, None
        for attempt in range(4):
            try:
                res = self._post(body)
            except ApiError as e:
                if e.code == "bad_request" and "fallback" in e.detail.lower() and "fallbacks" in body:
                    self.fallbacks = False
                    body.pop("fallbacks")
                    continue
                if e.code == "bad_request" and schema and "format" in body["output_config"]:
                    body["output_config"].pop("format")  # this schema was not accepted: ask for the JSON in words
                    content[-1]["text"] = user + "\n\nAnswer with ONLY one JSON object matching this JSON schema:\n" + json.dumps(schema)
                    last = e
                    continue
                if e.code == "too_large":  # one page image too big: skip this part, keep building
                    last = e
                    break
                raise
            self._count(res.get("model") if res.get("model") in PRICE else model, res.get("usage", {}))
            text = "".join(b.get("text", "") for b in res.get("content", []) if b.get("type") == "text").strip()
            stop = res.get("stop_reason")
            if stop == "refusal":
                last = "Claude declined this part"
                break
            if stop == "max_tokens":
                last = "answer cut off"
                if schema and "{" in text:
                    try:
                        salvage = extract_json(text) or salvage
                    except ValueError:
                        pass
                elif not schema and len(text) > len(salvage or ""):
                    salvage = text
                if body["max_tokens"] < MAX_OUT:
                    body["max_tokens"] = min(MAX_OUT, body["max_tokens"] * 2)
                    continue
                break
            if not schema:
                return text
            try:
                return fill_defaults(extract_json(text), schema)
            except ValueError as e:
                last = e
        print(f"\nskipped one answer: {last}", file=sys.stderr, flush=True)
        if not schema:
            return salvage or ""
        if salvage:
            return fill_defaults(salvage, schema)
        v = fill_defaults({}, schema)
        v["_failed"] = True
        return v


# ======================================================================= local model: downloads
def http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": f"LearnLume/{VERSION}"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode("utf-8"))


def download(url, dest, report, label, tries=30):
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    part = dest + ".part"
    for attempt in range(tries):
        have = os.path.getsize(part) if os.path.exists(part) else 0
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"LearnLume/{VERSION}", "Range": f"bytes={have}-"})
            with urllib.request.urlopen(req, timeout=45) as r:
                total = int(r.headers.get("Content-Length", 0)) + (have if r.status == 206 else 0)
                mode = "ab" if r.status == 206 else "wb"
                if mode == "wb":
                    have = 0
                with open(part, mode) as f:
                    last = 0
                    while True:
                        chunk = r.read(1 << 20)
                        if not chunk:
                            break
                        f.write(chunk)
                        have += len(chunk)
                        if time.time() - last > 1:
                            last = time.time()
                            report(have / total if total else 0, f"{label} {have / 1e6:.0f}/{total / 1e6:.0f}MB")
            if total and have < total:
                raise IOError("incomplete")
            os.replace(part, dest)
            return dest
        except urllib.error.HTTPError as e:
            if e.code == 416 and os.path.exists(part):
                os.replace(part, dest)
                return dest
            time.sleep(min(30, 2 + attempt * 2))
        except Exception:
            report(0.0, f"{label}: reconnecting ({attempt + 1})")
            time.sleep(min(30, 2 + attempt * 2))
    raise RuntimeError("Download failed after many retries: " + url)


MODELS = {
    "text": [{"repo": "unsloth/Qwen3-4B-Instruct-2507-GGUF", "match": "Q4_K_M", "stem": "qwen34binstruct2507"}],
    "draft": [{"repo": "unsloth/Qwen3-0.6B-GGUF", "match": "Q8_0", "stem": "qwen30.6b"}],
    "vision": [{"repo": "Qwen/Qwen3-VL-4B-Instruct-GGUF", "match": "Q4_K_M", "mmproj": True, "stem": "qwen3vl4b"},
               {"repo": "ggml-org/Qwen2.5-VL-3B-Instruct-GGUF", "match": "Q4_K_M", "mmproj": True, "stem": "qwen2.5vl3b"}],
}


def find_server():
    root = os.path.join(TOOLS, "llama")
    if not os.path.isdir(root):
        return None
    for r, _, files in os.walk(root):
        for f in files:
            if f.lower() in ("llama-server.exe", "llama-server"):
                return os.path.join(r, f)
    return None


def get_llama(report):
    server = find_server()
    if server:
        return server
    os.makedirs(TOOLS, exist_ok=True)
    rels = http_json("https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=6")
    bad = ("cuda", "cudart", "hip", "sycl", "opencl", "arm64", "kompute", "musa", "radeon")
    asset, seen = None, []
    for rel in rels:
        names = [a for a in rel.get("assets", []) if a["name"].endswith(".zip") and "win" in a["name"]]
        seen += [a["name"] for a in names]
        ok = [a for a in names if "x64" in a["name"] and not any(b in a["name"] for b in bad)]
        for pref in ("cpu", "avx2", "noavx", "vulkan", ""):
            cand = [a for a in ok if pref in a["name"]]
            if cand:
                asset = cand[0]
                break
        if asset:
            break
    if not asset:
        raise RuntimeError("No Windows build of llama.cpp found. Seen: " + ", ".join(seen[:30]))
    z = os.path.join(TOOLS, asset["name"])
    download(asset["browser_download_url"], z, report, "llama.cpp")
    with zipfile.ZipFile(z) as zz:
        zz.extractall(os.path.join(TOOLS, "llama"))
    return find_server()


def norm(s):
    return re.sub(r"[^a-z0-9.]", "", s.lower())


def local_model(kind):
    """an already downloaded model (also finds the files 0.1-0.3 downloaded)"""
    if not os.path.isdir(MODELS_DIR):
        return None
    files = [f for f in os.listdir(MODELS_DIR) if f.endswith(".gguf")]
    for spec in MODELS[kind]:
        main = [f for f in files if spec["match"] in f and "mmproj" not in f.lower() and spec["stem"] in norm(f)]
        if not main:
            continue
        if spec.get("mmproj"):
            mm = [f for f in files if "mmproj" in f.lower() and spec["stem"] in norm(f)]
            if not mm:
                continue
            return os.path.join(MODELS_DIR, main[0]), os.path.join(MODELS_DIR, mm[0])
        return os.path.join(MODELS_DIR, main[0]), None
    return None


def get_model(kind, report):
    have = local_model(kind)
    if have:
        return have
    os.makedirs(MODELS_DIR, exist_ok=True)
    last_err = None
    for spec in MODELS[kind]:
        try:
            files = [s["rfilename"] for s in http_json(f"https://huggingface.co/api/models/{spec['repo']}")["siblings"]]
            main = next(f for f in files if f.endswith(".gguf") and spec["match"] in f and "mmproj" not in f.lower())
            mm = None
            if spec.get("mmproj"):
                cands = [f for f in files if "mmproj" in f.lower() and f.endswith(".gguf")]
                cands.sort(key=lambda f: (0 if "Q8" in f else 1 if "F16" in f.upper() else 2))
                mm = cands[0]
            base = f"https://huggingface.co/{spec['repo']}/resolve/main/"
            prefix = spec["repo"].split("/")[-1].replace("-GGUF", "")

            def dest(f):  # file names always contain the model stem, so local_model() finds them later
                b = os.path.basename(f)
                return os.path.join(MODELS_DIR, b if spec["stem"] in norm(b) else prefix + "-" + b)
            m = download(base + main, dest(main), report, kind)
            p = download(base + mm, dest(mm), report, kind + " (eyes)") if mm else None
            return m, p
        except Exception as e:
            last_err = e
    raise RuntimeError(f"Could not download a {kind} model: {last_err}")


# ======================================================================= local model: server
class LocalLLM:
    """llama.cpp's server on this computer (the 0.3 engine). One call at a time; the right model is started
    when a call needs it (text, or the vision model for page images)."""

    def __init__(self, work, mock=False):
        self.work, self.mock = work, mock
        self.proc, self.kind, self.want = None, None, None
        self.calls = 0
        self.gen_tokens = 0
        self.in_tokens = 0
        self.cost = 0.0
        self.lock = threading.RLock()
        self.on_wait = None

    def check_key(self):
        pass

    def use(self, kind, model, mmproj=None, ctx=8192, draft=None):
        self.want = (kind, model, mmproj, ctx, draft)

    def start(self, kind, model, mmproj=None, ctx=8192, draft=None):
        if self.mock:
            self.kind = kind
            return
        if self.kind == kind and self.proc and self.proc.poll() is None:
            return
        self.stop()
        cpus = os.cpu_count() or 2
        gen_threads = max(1, cpus // 2 if cpus >= 8 else cpus)  # generation is memory-bound: physical cores
        args = [find_server(), "-m", model, "--port", str(PORT), "-c", str(ctx), "-t", str(gen_threads),
                "-tb", str(cpus), "--host", "127.0.0.1", "-np", "1"]
        self.last = (kind, model, mmproj, ctx, draft)
        if mmproj:
            args += ["--mmproj", mmproj]
        if draft:
            args += ["-md", draft, "--spec-draft-n-max", "8", "-td", str(gen_threads)]
        log = open(os.path.join(self.work, f"llama-server-{kind}.log"), "w")
        self.proc = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for _ in range(900):
            if self.proc.poll() is not None:
                if draft:  # draft model not compatible with this build -> run without it
                    return self.start(kind, model, mmproj, ctx, None)
                raise RuntimeError(f"llama-server ({kind}) stopped - see work/llama-server-{kind}.log")
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=2) as r:
                    if r.status == 200:
                        self.kind = kind
                        return
            except Exception:
                time.sleep(1)
        raise RuntimeError("llama-server did not start in 15 minutes")

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(20)
            except Exception:
                self.proc.kill()
        self.proc, self.kind = None, None

    def chat(self, system, user, schema=None, temperature=0.3, max_tokens=1500, image_png=None, tier="mid"):
        with self.lock:
            self.calls += 1
            if self.mock:
                return mock_answer(schema, user, image_png is not None)
            if self.want and (self.kind != self.want[0] or not self.proc or self.proc.poll() is not None):
                self.start(*self.want)
            return self._chat(system, user, schema, temperature, max_tokens, image_png)

    def _chat(self, system, user, schema, temperature, max_tokens, image_png):
        content = user
        if image_png:
            content = [{"type": "text", "text": user},
                       {"type": "image_url", "image_url": {"url": "data:image/png;base64," + base64.b64encode(image_png).decode()}}]
        body = {"messages": [{"role": "system", "content": system}, {"role": "user", "content": content}],
                "temperature": temperature, "max_tokens": max_tokens, "top_p": 0.9}
        err = None
        fails = 0
        json_only = True  # every failure so far was a bad/truncated JSON answer (not a server problem)
        salvage = None
        for attempt in range(6):
            mode = getattr(self, "json_mode", "rf")
            b = dict(body)
            if schema and mode == "rf":
                b["response_format"] = {"type": "json_schema", "json_schema": {"name": "out", "schema": schema}}
            elif schema and mode == "gbnf":
                b["grammar"] = schema_to_gbnf(schema)
            elif schema:  # free text + extraction (works with any server)
                b["messages"] = [b["messages"][0], {"role": "user", "content": content}]
                hint = "\n\nAnswer with ONLY one JSON object that matches this JSON schema, no other text:\n" + json.dumps(schema)
                if isinstance(content, str):
                    b["messages"][1]["content"] = content + hint
            try:
                req = urllib.request.Request(f"http://127.0.0.1:{PORT}/v1/chat/completions",
                                             data=json.dumps(b).encode("utf-8"), headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=5400) as r:
                    res = json.loads(r.read().decode("utf-8"))
                ch = res["choices"][0]
                txt = ch["message"].get("content") or ""
                self.gen_tokens += res.get("usage", {}).get("completion_tokens", 0)
                self.in_tokens += res.get("usage", {}).get("prompt_tokens", 0)
                if not schema:
                    return txt.strip()
                if ch.get("finish_reason") == "length":  # ran out of room: a complete answer, or retry with more room
                    try:
                        return fill_defaults(extract_json(txt, repair=False), schema)
                    except (json.JSONDecodeError, ValueError):
                        part = extract_json(txt) if "{" in txt else None
                        if part is not None and salvage is None:
                            salvage = part  # half an answer: used only if every try fails
                        body["max_tokens"] = min(3 * max_tokens, 6000, int(body["max_tokens"] * 1.7) + 200)
                        raise ValueError("answer cut off")
                return fill_defaults(extract_json(txt), schema)
            except (json.JSONDecodeError, KeyError, TypeError, ValueError) as e:
                err = e
                body["temperature"] = min(1.0, temperature + 0.2)
                continue
            except urllib.error.HTTPError as e:
                err = e
                json_only = False
                if e.code == 400 and schema:  # this server does not accept the format: switch for good
                    self.json_mode = {"rf": "gbnf", "gbnf": "free"}.get(mode, "free")
                    continue
                time.sleep(3)
            except Exception as e:  # server busy / crashed
                err = e
                json_only = False
                time.sleep(5)
            fails += 1
            if fails >= 2 and getattr(self, "last", None) and (self.last[4] or (self.proc and self.proc.poll() is not None)):
                k, m, mm, c, _ = self.last  # restart the server without the draft model
                self.kind = None
                self.start(k, m, mm, c, None)
        if schema and salvage is not None:
            return fill_defaults(salvage, schema)
        if schema and json_only:  # the model keeps answering badly on this one item: skip it, keep building
            print("\nskipped one answer (model gave no valid JSON 6 times)", file=sys.stderr, flush=True)
            v = fill_defaults({}, schema)
            v["_failed"] = True
            return v
        raise RuntimeError(f"model failed 6 times: {err}")


def schema_to_gbnf(schema):
    """JSON schema (the subset LearnLume uses) -> llama.cpp GBNF grammar. Works on any llama-server version."""
    rules = {}
    base = {
        "ws": "[ \\t\\n]{0,8}",
        "char": '[^"\\\\\\x7F\\x00-\\x1F] | "\\\\" (["\\\\/bfnrt] | "u" [0-9a-fA-F]{4})',
        "string": '"\\"" char{0,%d} "\\""' % int(os.environ.get("LEARNLUME_MAXSTR", "2000")),
        "boolean": '"true" | "false"',
        "integer": '"-"? [0-9]{1,4}',
    }
    count = [0]

    def lit(t):
        return '"' + t.replace("\\", "\\\\").replace('"', '\\"') + '"'

    def visit(sc):
        t = sc.get("type")
        count[0] += 1
        name = f"r{count[0]}"
        if "enum" in sc:
            rules[name] = " | ".join(lit(json.dumps(e, ensure_ascii=False)) for e in sc["enum"])
        elif t == "object":
            parts = []
            for i, (k, sub) in enumerate(sc.get("properties", {}).items()):
                parts.append(("" if i == 0 else '"," ws ') + lit(json.dumps(k)) + ' ws ":" ws ' + visit(sub))
            rules[name] = '"{" ws ' + " ws ".join(parts) + ' ws "}"'
        elif t == "array":
            item = visit(sc["items"])
            lo, hi = sc.get("minItems", 0), sc.get("maxItems")
            more_lo = max(0, lo - 1)
            more_hi = "" if hi is None else str(max(0, hi - 1))
            rep_ = f'("," ws {item} ws){{{more_lo},{more_hi}}}'
            inner = f"{item} ws {rep_}"
            rules[name] = f'"[" ws {inner} "]"' if lo >= 1 else f'"[" ws ({inner})? "]"'
        elif t == "string":
            n = sc.get("maxLength")
            n = min(n, int(os.environ.get("LEARNLUME_MAXSTR", "2000"))) if n else None
            return f'"\\"" char{{0,{n}}} "\\""' if n else "string"
        elif t == "integer":
            lo, hi = sc.get("minimum"), sc.get("maximum")
            if lo is not None and hi is not None and 0 <= lo <= hi <= 9:
                return f"[{lo}-{hi}]"
            return "integer"
        elif t == "boolean":
            return "boolean"
        else:
            return "string"
        return name
    root = visit(schema)
    lines = [f"root ::= ws {root} ws"] + [f"{k} ::= {v}" for k, v in rules.items()] + [f"{k} ::= {v}" for k, v in base.items()]
    return "\n".join(lines)

def extract_json(txt, repair=True):
    txt = txt.strip()
    try:
        return json.loads(txt)
    except Exception:
        pass
    m = re.search(r"\{.*\}", txt, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    i = txt.find("{")
    if i < 0 or not repair:
        raise ValueError("no JSON")
    v = repair_json(txt[i:])
    if v is None:
        raise ValueError("no JSON")
    return v


def repair_json(t):
    """close a JSON object that was cut off in the middle (the model hit max_tokens)"""
    cuts = [len(t)] + [k for k in range(len(t) - 1, 0, -1) if t[k] in ",{["][:40]
    for cut in cuts:
        s, stack, ins, esc = t[:cut], [], False, False
        for c in s:
            if ins:
                if esc:
                    esc = False
                elif c == "\\":
                    esc = True
                elif c == '"':
                    ins = False
            elif c == '"':
                ins = True
            elif c in "{[":
                stack.append("}" if c == "{" else "]")
            elif c in "}]" and stack:
                stack.pop()
        if esc:
            s = s[:-1]
        s = (s + '"' if ins else s).rstrip().rstrip(",:")
        try:
            v = json.loads(s + "".join(reversed(stack)))
            if isinstance(v, dict):
                return v
        except Exception:
            continue
    return None


def fill_defaults(v, schema):
    """make a parsed answer safe to use: missing keys get empty values of the right type"""
    t = schema.get("type")
    if t == "object":
        v = v if isinstance(v, dict) else {}
        for k, sub in schema.get("properties", {}).items():
            v[k] = fill_defaults(v.get(k), sub)
        return v
    if t == "array":
        return [fill_defaults(x, schema["items"]) for x in v] if isinstance(v, list) else []
    if t == "integer":
        try:
            return int(v)
        except Exception:
            return schema.get("minimum", 0)
    if t == "boolean":
        return bool(v) if isinstance(v, bool) else str(v).lower() == "true"
    if "enum" in schema:
        return v if v in schema["enum"] else schema["enum"][0]
    return "" if v is None else str(v)


def mock_answer(schema, user, image=False):
    rnd = random.Random(len(user))
    if image:
        return "שאלה 1\nנתונה קבוצה $A=\\{1,2,3\\}$. כמה תת-קבוצות יש לה? פתרון: $2^3=8$.\nשאלה 2\nכמה פונקציות? $3^2=9$."
    if not schema:
        if "final answer" in user.lower() or "short line" in user.lower():
            return "8"
        return "Mock notes: a definition, an example with $2^3=8$, and the formula $\\lceil n/k \\rceil$."

    def fake(s, key=""):
        t = s.get("type")
        if "enum" in s:
            return s["enum"][rnd.randrange(len(s["enum"]))]
        if t == "object":
            return {k: fake(v, k) for k, v in s.get("properties", {}).items()}
        if t == "array":
            n = max(s.get("minItems", 2), min(s.get("maxItems", 3), 3))
            return [fake(s["items"], key) for _ in range(n)]
        if t == "integer":
            return s.get("minimum", 0)
        if t == "number":
            return 1.0
        if t == "boolean":
            return True
        return f"mock {key}: $x^2+1$" if key in ("text", "explanation", "hook") else f"mock {key}"
    out = fake(schema)
    if isinstance(out, dict):
        for q in out.get("questions", []):
            if "check_code" in q:
                q["check_code"], q["answer_value"], q["correct"] = "answer = 8", "8", 0
                q["options"] = ["8", "6", "9", "3"]
        for i, u in enumerate(out.get("units", [])):
            u["section_ids"] = [i, i + 1]
            u["title"] = f"נושא {i + 1}"
        if "choice" in out:
            out["choice"] = 0
        if "number" in json.dumps(schema) and "questions" in out:
            for i, q in enumerate(out["questions"]):
                q["number"] = str(i + 1)
        if "unit" in out:
            out["unit"] = 0
        if "duration_minutes" in out:
            out["duration_minutes"] = 180
            out["parts"] = [{"name": "א", "answer": 1, "out_of": 1, "points_each": 19},
                            {"name": "ב", "answer": 3, "out_of": 4, "points_each": 27}]
    return out


# ======================================================================= PDFs
TYPE_RULES = [  # (type, regex on file name) - first match wins
    ("solution", r"sol|פתרון|פתרונות|answer|תשוב|_ans"),
    ("exam", r"exam|בחינ|מבחן|test|מועד"),
    ("assignment", r"(^|[^a-z])mm\d|ממן|ממ\"ן|maman|hw|assign|תרגיל|booklet"),
    ("syllabus", r"syllab|סילבוס|תכנית|לוח"),
    ("book", r"book|ספר|chapter|פרק|cp_|יחיד"),
]


def classify(name):
    low = os.path.basename(name).lower()
    for t, rx in TYPE_RULES:
        if re.search(rx, low):
            return t
    return "notes"


def repair_text(t):
    t = t.replace("ð", "נ").replace(" ", " ")
    lines = [l.strip() for l in t.split("\n")]
    out, buf = [], []
    for l in lines:
        if len(l) <= 3:
            if l:
                buf.append(l)
            continue
        if buf:
            out.append(" ".join(buf))
            buf = []
        out.append(l)
    if buf:
        out.append(" ".join(buf))
    t = "\n".join(out)
    t = re.sub(r"[ \t]+", " ", t)
    return re.sub(r"\n{3,}", "\n\n", t).strip()


def broken_score(raw):
    """0 = clean text, 1 = hopeless. High when math symbols were lost / text is shredded."""
    lines = [l.strip() for l in raw.split("\n") if l.strip()]
    if not lines:
        return 1.0
    short = sum(1 for l in lines if len(l) <= 3) / len(lines)
    weird = sum(1 for ch in raw if 0xE000 <= ord(ch) <= 0xF8FF or ch in "ð�") / max(1, len(raw))
    letters = sum(1 for ch in raw if ch.isalpha())
    empty = 1.0 if letters < 40 else 0.0
    return min(1.0, short * 1.4 + weird * 40 + empty)


def ingest(job_input, prog):
    import pymupdf
    pdfs = []
    for root, _, files in os.walk(job_input):
        for f in files:
            if f.lower().endswith(".pdf"):
                pdfs.append(os.path.join(root, f))
    pdfs.sort()
    if not pdfs:
        raise RuntimeError("No PDF files found in " + job_input)
    docs = []
    for i, path in enumerate(pdfs):
        name = os.path.relpath(path, job_input)
        try:
            doc = pymupdf.open(path)
        except Exception:
            continue
        pages = []
        for pno, page in enumerate(doc):
            raw = page.get_text()
            pages.append({"n": pno + 1, "text": repair_text(raw), "broken": round(broken_score(raw), 2)})
        toc = []
        try:
            toc = [[lvl, title.strip(), pg] for lvl, title, pg in doc.get_toc() if title.strip()]
        except Exception:
            pass
        docs.append({"id": f"d{i}", "name": name, "path": path, "type": classify(name), "pages": pages, "toc": toc,
                     "num": (re.findall(r"\d+", os.path.splitext(os.path.basename(name))[0]) or ["0"])[-1]})
        prog.set("ingest", (i + 1) / len(pdfs), os.path.basename(name))
    return docs


def render_page(path, pno, dpi=130):
    import pymupdf
    doc = pymupdf.open(path)
    return doc[pno - 1].get_pixmap(dpi=dpi).tobytes("png")


# ======================================================================= retrieval
def tokenize(t):
    return re.findall(r"[\w֐-׿]+", t.lower())


class BM25:
    def __init__(self, items, key=lambda x: x["text"]):
        self.items = items
        self.docs = [tokenize(key(x)) for x in items]
        self.N = len(self.docs)
        self.avg = sum(map(len, self.docs)) / max(1, self.N)
        self.df = collections.Counter()
        for d in self.docs:
            for w in set(d):
                self.df[w] += 1

    def rank(self, terms, k=10):
        terms = [t.lower() for t in terms if len(t) > 1]
        out = []
        for idx, d in enumerate(self.docs):
            tf = collections.Counter(d)
            s = 0.0
            for term in terms:
                for w, f in tf.items():
                    if w.startswith(term) or (len(term) > 3 and term in w):
                        idf = math.log(1 + (self.N - self.df[w] + 0.5) / (self.df[w] + 0.5))
                        s += idf * f * 2.2 / (f + 1.2 * (0.25 + 0.75 * len(d) / max(1, self.avg)))
            if s > 0:
                out.append((s, idx))
        out.sort(reverse=True)
        return [self.items[i] for _, i in out[:k]]


# ======================================================================= safe python check
def run_check(code, timeout=20):
    if not code or "answer" not in code:
        return None
    banned = ["import os", "import sys", "subprocess", "open(", "__import__", "shutil", "socket", "eval(", "exec(",
              "import requests", "urllib", "pathlib", "input("]
    if any(b in code for b in banned):
        return None
    prog = "import math, itertools, fractions, functools\ntry:\n    import sympy\nexcept Exception:\n    pass\n" + code + \
           "\nprint('@@ANSWER@@', answer)"
    try:
        r = subprocess.run([sys.executable, "-I", "-c", prog], capture_output=True, text=True, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        m = re.search(r"@@ANSWER@@ (.*)", r.stdout)
        return m.group(1).strip() if m else None
    except Exception:
        return None


def trivial_code(code):
    """`answer = 2` is not an independent check - only real computation counts"""
    body = [l for l in (code or "").splitlines() if l.strip() and not l.strip().startswith("#")]
    return len(body) <= 1 and bool(re.fullmatch(r"\s*answer\s*=\s*[-+]?[\d.]+\s*", body[0] if body else ""))


def option_value(o):
    o = str(o).strip().strip("$ ")
    m = re.fullmatch(r"([-+]?\d+(?:[./]\d+)?)(\s+[^\W\d_][\w\s\-]*)?", o)  # "510" or "699 counts"
    return m.group(1) if m else o


def align_key(q):
    """make `correct` point at the option that equals answer_value (models often mix the index up)"""
    av = q.get("answer_value")
    opts = q.get("options") or []
    if av is None or not opts:
        return q
    if 0 <= q.get("correct", -1) < len(opts) and same_value(option_value(opts[q["correct"]]), av):
        return q
    hits = [j for j, o in enumerate(opts) if same_value(option_value(o), av)]
    if len(hits) == 1:
        q["correct"] = hits[0]
    return q


def same_value(a, b):
    if a is None or b is None:
        return False
    a, b = str(a).strip().strip("'\"$ "), str(b).strip().strip("'\"$ ")
    try:
        return abs(float(eval(a.replace("^", "**"), {"__builtins__": {}})) -
                   float(eval(b.replace("^", "**"), {"__builtins__": {}}))) < 1e-9
    except Exception:
        return re.sub(r"\s", "", a.lower()) == re.sub(r"\s", "", b.lower())


# ======================================================================= schemas
def obj(props, req=None):
    return {"type": "object", "properties": props, "required": req or list(props)}


def arr(items, lo=None, hi=None):
    a = {"type": "array", "items": items}
    if lo is not None:
        a["minItems"] = lo
    if hi is not None:
        a["maxItems"] = hi
    return a


STR = {"type": "string"}
S_PLAN = obj({"course_title": STR, "units": arr(obj({
    "title": STR, "title_en": STR, "keywords": arr(STR, 4, 12), "section_ids": arr({"type": "integer"}, 0, 12)}), 3, 20)})
S_LESSON = obj({
    "title": STR, "hook": STR,
    "blocks": arr(obj({"kind": {"enum": ["definition", "idea", "example", "warning", "formula"]},
                       "title": STR, "text": STR, "source": STR}), 5, 10),
    "recipe": arr(STR, 3, 6), "one_sentence": STR})
S_QUESTIONS = obj({"questions": arr(obj({
    "question": STR, "options": arr(STR, 4, 4), "correct": {"type": "integer", "minimum": 0, "maximum": 3},
    "answer_value": STR, "check_code": STR, "explanation": STR, "deep_steps": arr(STR, 3, 8),
    "difficulty": {"enum": ["easy", "medium", "hard"]}}), 3, 4)})
S_CRITIC = obj({"well_posed": {"type": "boolean"}, "consistent_with_notes": {"type": "boolean"},
                "correct_option_really_correct": {"type": "boolean"}, "problem": {"type": "string", "maxLength": 160}})
S_SOLVE = obj({"reasoning": {"type": "string", "maxLength": 600}, "choice": {"type": "integer", "minimum": 0, "maximum": 3}})
S_WORKED = obj({"examples": arr(obj({"title": STR, "problem": STR, "steps": arr(STR, 2, 9), "final_answer": STR,
                                    "source": STR}), 0, 4)})
S_CARDS = obj({"cards": arr(obj({"front": STR, "back": STR}), 6, 12)})
S_EXAM_SPLIT = obj({"questions": arr(obj({"number": STR, "text": STR, "points": STR}), 0, 14)})
S_EXAM_EXPLAIN = obj({"short_answer": STR, "steps": arr(STR, 2, 10), "deep_steps": arr(STR, 3, 10),
                      "unit": {"type": "integer"}, "question_type": STR})
S_RECIPE = obj({"how_it_appears": STR, "template": arr(STR, 3, 8), "traps": arr(STR, 2, 5), "keywords": arr(STR, 2, 6)})
S_STRUCT = obj({"duration_minutes": {"type": "integer"}, "material_allowed": STR,
                "parts": arr(obj({"name": STR, "answer": {"type": "integer"}, "out_of": {"type": "integer"},
                                  "points_each": {"type": "integer"}}), 1, 4), "notes": arr(STR, 0, 6)})
S_TR = obj({"items": arr(STR)})

SYS = ("You are an expert university teacher writing for students with ADHD who start from zero. "
       "Short sentences. One idea per sentence. Concrete examples. Use ONLY facts found in the provided course "
       "material; never invent course facts. Write math in LaTeX between $...$ (e.g. $\\lceil n/k \\rceil$). "
       "Write in clear English.")


# ======================================================================= the builder
class Builder:
    def __init__(self, a):
        self.a = a
        self.job = os.path.abspath(a.job)
        self.inp = os.path.join(self.job, "input")
        self.work = os.path.join(self.job, "work")
        self.out = os.path.join(self.job, "output")
        os.makedirs(self.work, exist_ok=True)
        self.local = backend_choice(a.backend) == "local"
        self.prog = Progress(self.out, a.name, STAGES_LOCAL if self.local else STAGES)
        self.cache = Cache(os.path.join(self.work, "cache.json"))
        if self.local:
            self.llm = LocalLLM(self.work, a.mock)
        else:
            self.llm = ClaudeLLM(self.work, a.mock, a.models or load_settings().get("preset") or DEFAULT_PRESET)
        self.llm.on_wait = lambda sec: self.prog.set(self.prog.stage, self.prog.frac, f"⏳ {round(sec)}s")
        self.models = {}
        self.m = dict((MODES_LOCAL if self.local else MODES)[a.mode])
        if a.max_units:
            self.m["max_units"] = a.max_units
        if a.max_exams is not None:
            self.m["max_exams"] = a.max_exams
        self.langs = [l for l in a.langs.split(",") if l in LANG_NAMES] or ["he"]
        # one non-English language: write the student-facing text straight in it (no translation pass: faster, cheaper)
        self.direct = self.langs[0] if len(self.langs) == 1 and self.langs[0] != "en" else None
        self.SYS_OUT = SYS if not self.direct else SYS.replace(
            "Write in clear English.",
            f"Write every student-facing text value in clear, simple {LANG_NAMES[self.direct]}, the way a good local "
            f"teacher would say it, using the course's own terms in that language. Keep JSON keys, numbers and LaTeX "
            f"exactly as they are.")
        self.workers = 1 if self.local else max(1, min(12, a.workers))

    def n(self, api, local):
        """how much text a step sends: the local model has a small context and a slow CPU"""
        return local if self.local else api

    def cached(self, key, fn):
        if self.direct and key.split(":", 1)[0] in ("lesson", "q", "worked", "exq", "recipe", "struct", "cards"):
            key = f"{self.direct}|{key}"  # these answers are written in the target language
        v = self.cache.get(key)
        if v is None:
            v = fn()
            if not (isinstance(v, dict) and v.get("_failed")):
                self.cache.put(key, v)
        return v

    def text_llm(self):  # local model: the next calls need the text model (Claude: nothing to start)
        if self.local:
            m, _ = self.models.get("text", (None, None))
            self.llm.use("text", m, None, 8192, (self.models.get("draft") or (None,))[0])

    # ---------------------------------------------------------------- setup
    def setup(self):
        p = self.prog
        if not self.local:
            p.set("setup", 0.3, "Claude")
            self.llm.check_key()
            p.set("setup", 1.0, "ready")
            return
        if self.a.mock:
            p.set("setup", 1.0, "mock")
            return
        p.set("setup", 0.02, "llama.cpp")
        get_llama(lambda f, n: p.set("setup", 0.02 + 0.08 * f, n))
        self.models["text"] = get_model("text", lambda f, n: p.set("setup", 0.1 + 0.45 * f, n))
        try:
            self.models["draft"] = get_model("draft", lambda f, n: p.set("setup", 0.5, n))
        except Exception:
            pass
        if not self.a.no_ocr:
            try:
                self.models["vision"] = get_model("vision", lambda f, n: p.set("setup", 0.55 + 0.45 * f, n))
            except Exception as e:
                p.log.append("vision model unavailable, continuing without OCR: " + str(e)[:80])
        self.text_llm()
        p.set("setup", 1.0, "ready")

    # ---------------------------------------------------------------- plan
    def plan(self, docs):
        self.prog.set("plan", 0.1)
        sections = []
        for d in docs:
            if d["type"] not in ("book", "notes") or not d["toc"]:
                continue
            toc = d["toc"]
            for i, (lvl, title, pg) in enumerate(toc):
                if lvl > 2 or pg < 1 or re.search(r"תוכן העניינים|contents|הקדמה|preface|index|מפתח", title, re.I):
                    continue
                end = len(d["pages"])
                for lvl2, _, pg2 in toc[i + 1:]:
                    if lvl2 <= lvl and pg2 > pg:
                        end = pg2 - 1
                        break
                sections.append({"id": len(sections), "doc": d["id"], "title": title, "from": pg, "to": max(pg, end)})
        if not sections:
            sections = self.headings(docs)
        syllabus = "\n".join(p["text"] for d in docs if d["type"] == "syllabus" for p in d["pages"])[:3000]
        listing = "\n".join(f"{s['id']}: {s['title']} (pages {s['from']}-{s['to']})" for s in sections[:160])
        if not listing:
            sample = [p["text"][:200] for d in docs for p in d["pages"][::4]][:40]
            listing = "No headings found. Page samples:\n" + "\n---\n".join(sample)
        n = self.m["max_units"]

        def ask():
            self.text_llm()
            return self.llm.chat(SYS, f"""Plan the study units of this university course.
Group the sections below into at most {n} units, in the order a student should learn them.
Each unit: title in the course's own language, title_en in English, 4-12 keywords (course language AND English,
single words that appear in the material), section_ids = the ids of the sections it covers.
Skip sections that are not course content (exercise lists, answers, appendices).

SYLLABUS (may be empty):
{syllabus}

SECTIONS:
{listing}""", S_PLAN, 0.2, 2500)
        plan = self.cached("plan", ask)
        by_id = {s["id"]: s for s in sections}
        units = []
        for i, u in enumerate(plan.get("units", [])[:n]):
            units.append({"id": f"u{i + 1}", "title": u.get("title") or u.get("title_en") or f"Unit {i + 1}",
                          "title_en": u.get("title_en", ""), "keywords": u.get("keywords", []),
                          "sections": [by_id[x] for x in u.get("section_ids", []) if x in by_id]})
        self.prog.set("plan", 1.0, f"{len(units)} נושאים")
        return plan.get("course_title") or self.a.name, units

    def headings(self, docs):
        import pymupdf
        secs = []
        for d in docs:
            if d["type"] not in ("book", "notes"):
                continue
            try:
                doc = pymupdf.open(d["path"])
            except Exception:
                continue
            sizes, lines = [], []
            for pno, page in enumerate(doc):
                for b in page.get_text("dict")["blocks"]:
                    for l in b.get("lines", []):
                        txt = "".join(s["text"] for s in l["spans"]).strip()
                        if not l["spans"] or len(txt) < 3:
                            continue
                        sz = max(s["size"] for s in l["spans"])
                        sizes.append(sz)
                        lines.append((pno + 1, sz, txt))
            if not sizes:
                continue
            med = sorted(sizes)[len(sizes) // 2]
            heads = [(p, t) for p, s, t in lines if s >= med * 1.3 and len(t) < 80]
            for i, (p, t) in enumerate(heads):
                nxt = heads[i + 1][0] - 1 if i + 1 < len(heads) else len(d["pages"])
                secs.append({"id": len(secs), "doc": d["id"], "title": t, "from": p, "to": max(p, nxt)})
        return secs

    def unit_pages(self, docs, units):
        by = {d["id"]: d for d in docs}
        practice = [{"doc": d["id"], "n": p["n"], "text": p["text"]} for d in docs
                    if d["type"] in ("assignment", "solution", "notes") for p in d["pages"]]
        bm_practice = BM25(practice) if practice else None
        allpages = [{"doc": d["id"], "n": p["n"], "text": p["text"]} for d in docs if d["type"] != "exam" for p in d["pages"]]
        bm_all = BM25(allpages) if allpages else None
        k = self.m["pages_per_unit"]
        for u in units:
            pages = []
            for s in u["sections"]:
                last = min(s["to"], len(by[s["doc"]]["pages"]))
                rng = [{"doc": s["doc"], "n": n, "text": by[s["doc"]]["pages"][n - 1]["text"]} for n in range(s["from"], last + 1)]
                if len(rng) > k:
                    best = BM25(rng).rank(u["keywords"], k - 1)
                    rng = [rng[0]] + [r for r in best if r is not rng[0]]
                pages += rng
            pages = pages[: k + 2]
            if not pages and bm_all:
                pages = bm_all.rank(u["keywords"], k)
            if bm_practice:
                have = {(p["doc"], p["n"]) for p in pages}
                pages += [r for r in bm_practice.rank(u["keywords"], 3) if (r["doc"], r["n"]) not in have]
            u["pages"] = [(p["doc"], p["n"]) for p in pages]

    # ---------------------------------------------------------------- parallel helper
    def pmap(self, stage, items, fn, label=lambda x: "", span=(0.0, 1.0)):
        """run fn over items with several Claude calls at once; results keep the order of items"""
        out = [None] * len(items)
        if not items:
            self.prog.set(stage, span[1])
            return out
        done = [0]
        lock = threading.Lock()
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.workers) as ex:
            futs = {ex.submit(fn, it): i for i, it in enumerate(items)}
            for f in concurrent.futures.as_completed(futs):
                i = futs[f]
                out[i] = f.result()
                with lock:
                    done[0] += 1
                    self.prog.set(stage, span[0] + (span[1] - span[0]) * done[0] / len(items), label(items[i]))
        return out

    # ---------------------------------------------------------------- OCR
    def ocr(self, docs, needed):
        """pages whose text came out broken (lost math symbols, scrambled Hebrew) are read again from the image"""
        by = {d["id"]: d for d in docs}
        thr = self.a.ocr_threshold if self.a.ocr_threshold is not None else self.m["ocr"]
        todo = [] if self.a.no_ocr else [(d, n) for d, n in needed if by[d]["pages"][n - 1]["broken"] >= thr]
        if self.local and todo and not self.a.mock:
            if "vision" not in self.models:
                self.prog.log.append("no vision model - using extracted text")
                todo = []
            else:
                self.llm.use("vision", *self.models["vision"], ctx=8192)

        def read(job):
            did, n = job
            d = by[did]

            def go():
                png = b"x" if self.a.mock else render_page(d["path"], n, self.m["dpi"])
                return self.llm.chat("You transcribe university course pages exactly.",
                                     "Transcribe this page exactly, in its original language (Hebrew stays Hebrew). "
                                     "Keep the reading order and the numbering of questions and steps. Write every "
                                     "mathematical expression in LaTeX between $...$. Output only the transcription.",
                                     None, 0.0, self.n(3000, 1800), image_png=png)
            return self.cached(f"ocr:{d['name']}:{n}", go)
        res = self.pmap("ocr", todo, read, lambda j: f"{os.path.basename(by[j[0]]['name'])} עמ' {j[1]}")
        texts = dict(zip(todo, res))
        self.text_llm()
        self.prog.set("ocr", 1.0, f"{len(todo)} עמודים")
        return lambda did, n: texts.get((did, n)) or by[did]["pages"][n - 1]["text"]

    # ---------------------------------------------------------------- per unit
    def notes(self, units, text_of, docs):
        by = {d["id"]: d for d in docs}
        per = self.n(4, 2)
        jobs = [(u, u["pages"][i:i + per]) for u in units for i in range(0, len(u["pages"]), per)]

        def mapf(job):
            u, chunk = job
            srcs = [f"{os.path.basename(by[did]['name'])} p.{n}" for did, n in chunk]
            cut = self.n(6000, 3000)
            body = "\n\n".join(f"PAGE [{sname}]:\n\"\"\"{text_of(did, n)[:cut]}\"\"\"" for sname, (did, n) in zip(srcs, chunk))
            return self.cached(f"note4:{u['title']}:" + ",".join(f"{d}:{n}" for d, n in chunk), lambda: self.llm.chat(SYS, f"""{body}

Extract study notes for the unit "{u['title_en'] or u['title']}" from the course page(s) above.
Keep: every definition, theorem and formula (LaTeX), and every solved example WITH all of its steps and numbers.
Rewrite broken extraction into clean English. Start each part with its [file p.N] tag.
If the pages have nothing for this unit, answer exactly: NONE.""", None, 0.1, self.n(3000, 1500)))
        res = self.pmap("notes", jobs, mapf, lambda j: j[0]["title"], (0.0, 0.85))
        parts = collections.defaultdict(list)
        for (u, _), t in zip(jobs, res):
            if t and not t.strip().upper().startswith("NONE"):
                parts[u["id"]].append(t.strip())

        def reduce(u):
            notes = "\n\n".join(parts[u["id"]])
            if len(notes) > self.n(20000, 9000):
                joined = notes[:self.n(60000, 24000)]
                notes = self.cached(f"reduce2:{u['title']}", lambda: self.llm.chat(SYS, f"""Condense these notes for the unit
"{u['title_en'] or u['title']}" to at most {self.n(14000, 6000)} characters. Keep every definition and formula and at least
{self.n(4, 3)} solved examples with all their steps. Keep the [file p.N] source tags.

{joined}""", None, 0.1, self.n(5000, 2200)))
            u["notes"] = notes or "(no material found)"
        self.pmap("notes", units, reduce, lambda u: u["title"], (0.85, 1.0))

    def lessons(self, units):
        def one(u):
            u["lesson"] = self.cached(f"lesson:{u['title']}", lambda: self.llm.chat(self.SYS_OUT, f"""COURSE NOTES:
{u['notes'][:self.n(14000, 6000)]}

Write a from-zero lesson
about "{u['title_en'] or u['title']}" for a student with ADHD, based ONLY on these course notes.
Blocks in order: a definition, the idea in plain words, 2-3 concrete examples taken from the notes, the key formula,
a common-mistake warning (add blocks only if the unit really needs them). Each block at most 3 short sentences.
Plain words, short sentences, one idea per sentence; never assume knowledge the notes did not build first.
"source" = the [file p.N] tag the fact came from. "recipe" = the steps to solve an exam question on this unit.
"hook" = one curious question that makes the student want to learn this.""", S_LESSON, 0.4, self.n(3500, 2400), tier="top"))
        self.pmap("lessons", units, one, lambda u: u["title"])

    def questions(self, units):
        focus = ["the basic definition and direct use", "a calculation like in the solved examples",
                 "a tricky exam-style case", "a common mistake"]
        jobs = [(u, r) for u in units for r in range(self.m["q_rounds"])]

        def one(job):
            u, r = job
            f = focus[r % 4]
            return self.cached(f"q:{u['title']}:{r}", lambda: self.llm.chat(self.SYS_OUT, f"""COURSE NOTES:
{u['notes'][:self.n(14000, 6000)]}

Create multiple-choice questions
about "{u['title_en'] or u['title']}" (focus: {f}), based on the course notes.
Rules:
- exactly one correct option; wrong options are plausible common mistakes; options are short.
- answer_value: the correct answer as a short value (a number when possible).
- check_code: short Python that COMPUTES the answer independently (brute force or formula) and stores it in a
  variable named `answer`. Only math / itertools / fractions. If it is not computable write `answer = None`.
- explanation: 1-2 sentences. deep_steps: a very detailed step-by-step explanation for a student who still
  did not understand (start from the definition, use small numbers, show every calculation).""", S_QUESTIONS, 0.7, self.n(4000, 2800)))
        res = self.pmap("questions", jobs, one, lambda j: j[0]["title"])
        for u in units:
            u["raw_questions"] = []
        for (u, _), r in zip(jobs, res):
            u["raw_questions"] += r.get("questions", [])

    def verify(self, units):
        votes = self.m["votes"]
        allq = []
        for u in units:
            u["questions"] = []
            for q in u["raw_questions"]:
                if isinstance(q.get("options"), list) and len(q["options"]) == 4:
                    align_key(q)
                    allq.append((u, q, "\n".join(f"{j}) {o}" for j, o in enumerate(q["options"]))))

        def check_one(job):
            u, q, opts = job

            def check():
                crit = self.llm.chat("You are a strict exam reviewer.", f"""COURSE NOTES:
{u['notes'][:self.n(8000, 4000)]}

Review this multiple-choice question.
Question: {q['question']}
Options:
{opts}
Marked correct option: {q['correct']}
Is it clearly worded and solvable as written? Is it consistent with the notes? Is the marked option really correct?
problem: one short sentence (at most 15 words), or "" if there is no problem.""", S_CRITIC, 0.0, 800)
                if crit.get("_failed"):
                    return {"computed": None, "code_ok": None, "ballots": [], "majority": None, "agree": 0,
                            "rejected": "critic gave no answer", "_failed": True}
                if not (crit.get("well_posed") and crit.get("consistent_with_notes") and crit.get("correct_option_really_correct", True)):
                    return {"computed": None, "code_ok": None, "ballots": [], "majority": None, "agree": 0,
                            "rejected": crit.get("problem", "critic")}
                code = q.get("check_code", "")
                computed = None if trivial_code(code) else run_check(code)
                code_ok = None if computed in (None, "None") else (
                    same_value(computed, q.get("answer_value")) and same_value(computed, option_value(q["options"][q["correct"]])))
                ballots = []
                need = math.ceil(votes * 0.6)
                for _ in range(votes):
                    r = self.llm.chat("You are a careful student. Think briefly step by step (at most 5 short lines), then choose.",
                                      f"Question: {q['question']}\nOptions:\n{opts}\nChoose the index of the correct option.",
                                      S_SOLVE, 0.8, 500, tier="fast")
                    ballots.append(r.get("choice"))
                    agree = ballots.count(q["correct"])
                    if code_ok and agree >= 1:
                        break
                    if agree >= need or len(ballots) - agree > votes - need:
                        break
                top, n = collections.Counter(ballots).most_common(1)[0]
                return {"computed": computed, "code_ok": code_ok, "ballots": ballots, "majority": top, "agree": n}
            return self.cached("v2:" + q["question"][:150], check)
        res = self.pmap("verify", allq, check_one, lambda j: j[0]["title"])
        for (u, q, _), v in zip(allq, res):
            if v.get("rejected"):
                continue
            maj_ok = v["majority"] == q["correct"] and (v["agree"] >= math.ceil(votes * 0.6) or
                                                        (v["code_ok"] and v["agree"] >= 1 and len(v["ballots"]) == v["agree"]))
            if v["code_ok"] is False:
                status = "drop"  # key contradicts the computation; keep only if the vote picks the computed option
                for j, o in enumerate(q["options"]):
                    if v["computed"] is not None and same_value(option_value(o), v["computed"]) and v["majority"] == j:
                        q["correct"], status = j, "likely"
                        break
            elif v["code_ok"] and maj_ok:
                status = "verified"
            elif maj_ok or v["code_ok"]:
                status = "likely"
            else:
                status = "drop"
            if status != "drop":
                sig = re.sub(r"\W+", "", q["question"].lower())[:60]
                if sig not in {re.sub(r"\W+", "", x["question"].lower())[:60] for x in u["questions"]}:
                    u["questions"].append({k: q.get(k) for k in ("question", "options", "correct", "explanation",
                                                                 "deep_steps", "difficulty")}
                                          | {"trust": status, "votes": f"{v['agree']}/{votes}"})

    def worked(self, units):
        def one(u):
            r = self.cached(f"worked:{u['title']}", lambda: self.llm.chat(self.SYS_OUT, f"""COURSE NOTES:
{u['notes'][:self.n(14000, 6000)]}

From these course notes, take up to
{self.m['worked']} SOLVED exercises (only ones that really appear in the notes with a solution) and present each as a
worked example: a short problem statement, the solution in small steps (keep the course's reasoning and numbers
exactly), the final answer, and its [file p.N] source. If there are none, return an empty list.""", S_WORKED, 0.2, self.n(4000, 2400), tier="top"))
            u["worked"] = [w for w in r.get("examples", []) if len(w.get("steps", [])) >= 2][: self.m["worked"]]
        self.pmap("worked", units, one, lambda u: u["title"])

    # ---------------------------------------------------------------- exams
    def exams(self, docs, units, text_of):
        exams = [d for d in docs if d["type"] == "exam"]
        sols = [d for d in docs if d["type"] == "solution" and not is_assignment_solution(d["name"])]
        exams.sort(key=lambda d: int(d["num"]) if d["num"].isdigit() else 0, reverse=True)
        exams = exams[: self.m["max_exams"]]
        unit_list = "\n".join(f"{i}: {u['title_en'] or u['title']}" for i, u in enumerate(units))
        prepared = []

        def split_one(ex):
            sol = next((s for s in sols if s["num"] == ex["num"]), None)
            ex_text = "\n".join(text_of(ex["id"], p["n"]) for p in ex["pages"])
            sol_text = "\n".join(text_of(sol["id"], p["n"]) for p in sol["pages"]) if sol else ""
            split = self.cached(f"exsplit:{ex['name']}", lambda: self.llm.chat(SYS, f"""Split this exam into its questions.
For each question: number (as written), the full question text in the ORIGINAL language (keep $LaTeX$), points if written.
Skip the cover page instructions.

EXAM:
{ex_text[:self.n(30000, 9000)]}""", S_EXAM_SPLIT, 0.0, self.n(6000, 3500)))
            return sol, sol_text, split.get("questions", [])
        splits = self.pmap("exams", exams, split_one, lambda e: os.path.basename(e["name"]), (0.0, 0.15))
        jobs = [(ei, ex, sol, sol_text, q) for ei, (ex, (sol, sol_text, qs)) in enumerate(zip(exams, splits)) for q in qs]

        def explain_one(job):
            ei, ex, sol, sol_text, q = job
            sol_part = slice_solution(sol_text, q["number"]) if sol_text else ""

            def explain():
                src = ("OFFICIAL SOLUTION (follow it exactly, do not change the answer):\n" + sol_part[:self.n(8000, 4000)]) if sol_part \
                    else "There is no official solution. Solve it carefully yourself."
                return self.llm.chat(self.SYS_OUT, f"""Explain the solution of this exam question for a student with ADHD.
steps: the solution in small numbered steps. deep_steps: an even more detailed explanation from zero, every calculation shown.
short_answer: the final answer in one line. unit: the index of the matching unit. question_type: 3-6 words.

UNITS:
{unit_list}

QUESTION {q['number']}:
{q['text'][:self.n(6000, 3000)]}

{src}""", S_EXAM_EXPLAIN, 0.2, self.n(4000, 2600), tier="top")
            e = self.cached(f"exq:{ex['name']}:{q['number']}", explain)
            trust = "sourced"
            if not sol_part:
                def vote():
                    return sum(1 for _ in range(2) if same_value(self.llm.chat(
                        "Solve carefully. Return only the final answer in one short line.",
                        q["text"][:self.n(6000, 3000)], None, 0.7, 600, tier="mid")[:80], e.get("short_answer", "")[:80]))
                trust = "likely" if self.cached(f"exvote:{ex['name']}:{q['number']}", vote) >= 1 else "unverified"
            if not (isinstance(e.get("unit"), int) and 0 <= e["unit"] < len(units)):
                e["unit"] = -1
            return {"number": q["number"], "text": q["text"], "points": q.get("points", ""), **e, "trust": trust}
        res = self.pmap("exams", jobs, explain_one, lambda j: f"{os.path.basename(j[1]['name'])} · {j[4]['number']}", (0.15, 1.0))
        out = []
        for ei, ex in enumerate(exams):
            sol = splits[ei][0]
            out.append({"id": f"e{ei + 1}", "name": os.path.splitext(os.path.basename(ex["name"]))[0],
                        "has_solution": bool(sol), "questions": [r for j, r in zip(jobs, res) if j[0] == ei],
                        "cover": text_of(ex["id"], 1)[:2500]})
        self.prog.set("exams", 1.0)
        return out

    def recipes(self, units, exams):
        def one(iu):
            i, u = iu
            seen = [f"- ({e['name']} q{q['number']}) {q.get('question_type', '')}: {q['text'][:400]}"
                    for e in exams for q in e["questions"] if q.get("unit") == i]
            u["exam_refs"] = [{"exam": e["id"], "q": q["number"]} for e in exams for q in e["questions"] if q.get("unit") == i]
            seen_txt = "\n".join(seen)[:self.n(8000, 3500)] or "(none)"
            u["recipe_card"] = self.cached(f"recipe:{u['title']}", lambda: self.llm.chat(self.SYS_OUT, f"""Write the exam recipe card
for the unit "{u['title_en'] or u['title']}".
how_it_appears: how this unit shows up in the exams (from the list below; if the list is empty, from the notes).
template: a fill-in-the-blank solution template a student can follow even without studying, for example
"Pigeons = ____ ; holes = ____ ; since ____ > ____ ...". traps: common mistakes. keywords: words in a question that
signal this unit.

PAST EXAM QUESTIONS ON THIS UNIT:
{seen_txt}

NOTES:
{u['notes'][:self.n(8000, 3000)]}""", S_RECIPE, 0.3, self.n(2500, 1800)))
        self.pmap("recipes", list(enumerate(units)), one, lambda iu: iu[1]["title"])

    def extras(self, exams, units):
        self.prog.set("extras", 0.2)
        cover = exams[0]["cover"] if exams else ""
        struct = None
        if cover:
            struct = self.cached("struct", lambda: self.llm.chat(self.SYS_OUT, f"""From this exam cover page, extract the exam
structure: duration in minutes, which material is allowed, the parts (name, how many questions to answer, out of how
many, points each) and important notes.

COVER PAGE:
{cover}""", S_STRUCT, 0.0, 1200))
        cheat = []
        for u in units:
            L = u.get("lesson", {})
            cheat.append({"unit": u["id"], "title": L.get("title", u["title"]),
                          "items": [b for b in L.get("blocks", []) if b.get("kind") in ("definition", "formula")],
                          "one": L.get("one_sentence", "")})
        self.prog.set("extras", 1.0)
        return build_strategy(struct), cheat

    def cards(self, units):
        def one(u):
            lesson_json = json.dumps(u["lesson"], ensure_ascii=False)[:self.n(9000, 5000)]
            r = self.cached(f"cards:{u['title']}", lambda: self.llm.chat(self.SYS_OUT, f"""Make flashcards for
"{u['title_en'] or u['title']}". Front: a short question. Back: at most 2 short sentences.
LESSON: {lesson_json}""", S_CARDS, 0.4, self.n(2000, 1600)))
            u["cards"] = r.get("cards", [])
        self.pmap("cards", units, one, lambda u: u["title"])

    def glossary(self, units):
        """course terms in the course's own language, so translations use the course's words"""
        terms = []
        for u in units:
            terms.append(u["title"])
            terms += [k for k in u.get("keywords", []) if re.search(r"[\u0590-\u05FF\u0600-\u06FF\u0400-\u04FF]", k)]
        return ", ".join(dict.fromkeys(t for t in terms if t))[:1200]

    def translate(self, content, lang, f0, f1):
        if lang == "en" or lang == self.direct:  # already written in this language
            self.prog.set("translate", f1)
            return content
        out = json.loads(json.dumps(content))
        paths = collect_strings(out)
        batch = self.n(40, 16)
        groups = [paths[i:i + batch] for i in range(0, len(paths), batch)]
        system = (f"You are a professional translator into {LANG_NAMES[lang]} for university study material. "
                  "Natural, simple language for students, the way a good local teacher would say it. "
                  "Keep numbers, LaTeX between $...$ and symbols exactly." +
                  (f" Use the course's own terms where they fit: {self.terms}" if getattr(self, "terms", "") else ""))

        def one(ps):
            src = [get_path(out, p) for p in ps]

            def tr():
                r = self.llm.chat(system, f"Translate each item into {LANG_NAMES[lang]}. Return the same number of items in "
                                  "the same order.\n" + json.dumps(src, ensure_ascii=False), S_TR, 0.2, self.n(8000, 4000))
                return r if len(r.get("items", [])) == len(src) else {"items": src}
            return self.cached(f"tr:{lang}:" + "|".join(s[:50] for s in src), tr)
        res = self.pmap("translate", groups, one, lambda g: LANG_NAMES[lang], (f0, f1))
        for ps, r in zip(groups, res):
            for p_, t in zip(ps, r["items"]):
                set_path(out, p_, t)
        self.prog.set("translate", f1)
        return out

    # ---------------------------------------------------------------- run
    def run(self):
        p = self.prog
        p.set("setup", 0.0)
        self.setup()
        docs = ingest(self.inp, p)
        json.dump([{k: v for k, v in d.items() if k != "pages"} | {"pages": len(d["pages"])} for d in docs],
                  open(os.path.join(self.work, "docs.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        title, units = self.plan(docs)
        if not units:
            raise RuntimeError("Could not find any topics in the PDFs")
        self.unit_pages(docs, units)
        chosen = sorted([d for d in docs if d["type"] == "exam"],
                        key=lambda d: int(d["num"]) if d["num"].isdigit() else 0, reverse=True)[: self.m["max_exams"]]
        nums = {d["num"] for d in chosen}
        needed = [x for u in units for x in u["pages"]]
        needed += [(d["id"], pg["n"]) for d in chosen for pg in d["pages"]]
        needed += [(d["id"], pg["n"]) for d in docs if d["type"] == "solution" and d["num"] in nums
                   and not is_assignment_solution(d["name"]) for pg in d["pages"]]
        text_of = self.ocr(docs, list(dict.fromkeys(needed)))
        self.notes(units, text_of, docs)
        self.lessons(units)
        self.questions(units)
        self.verify(units)
        self.worked(units)
        exams = self.exams(docs, units, text_of)
        self.recipes(units, exams)
        strategy, cheat = self.extras(exams, units)
        self.cards(units)
        content = {"course": title, "units": [{
            "id": u["id"], "title": u["lesson"].get("title") or u["title"], "lesson": u["lesson"],
            "questions": u["questions"], "worked": u["worked"], "cards": u["cards"], "recipe": u["recipe_card"],
            "exam_refs": u["exam_refs"], "keywords": u["keywords"]} for u in units],
            "exams": [{k: e[k] for k in ("id", "name", "has_solution", "questions")} for e in exams],
            "strategy": strategy, "cheat": cheat}
        json.dump(content, open(os.path.join(self.work, "content_en.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        self.terms = self.glossary(units)
        per_lang = {}
        for li, lang in enumerate(self.langs):
            per_lang[lang] = self.translate(content, lang, li / len(self.langs), (li + 1) / len(self.langs))
        self.llm.stop()
        p.set("build", 0.3)
        path = build_app(self.out, per_lang, self.langs[0], content, self.a.name)
        stats = {"version": VERSION, "mode": self.a.mode, "backend": "local" if self.local else "api",
                 "models": None if self.local else self.llm.models, "llm_calls": self.llm.calls,
                 "input_tokens": self.llm.in_tokens, "generated_tokens": self.llm.gen_tokens, "cost_usd": round(self.llm.cost, 2), "minutes": round((time.time() - p.t0) / 60, 1),
                 "units": len(units), "exams": len(exams), "questions": sum(len(u["questions"]) for u in units),
                 "trust": dict(collections.Counter(q["trust"] for u in units for q in u["questions"]))}
        json.dump(stats, open(os.path.join(self.out, "stats.json"), "w"), indent=1)
        p.state = "done"
        p.set("done", 1.0, "האפליקציה מוכנה")
        return path


def is_assignment_solution(name):
    return bool(re.search(r"mm|ממן|ממ\"ן|maman|hw|assign|booklet", os.path.basename(name).lower()))


def slice_solution(sol_text, number):
    """the part of an official solution that belongs to question `number`"""
    num = re.sub(r"\D", "", str(number)) or str(number)
    head = r"(שאלה|question|תשובה)"
    starts = [m.start() for m in re.finditer(head + r"\s*" + re.escape(num) + r"(?!\d)", sol_text, re.I)]
    starts += [m.start() for m in re.finditer(r"(?<!\d)" + re.escape(num) + r"\s*" + head, sol_text, re.I)]
    if not starts:
        return ""
    start = min(starts)
    end = len(sol_text)
    for x in re.finditer(head + r"\s*(\d+)|(?<!\d)(\d+)\s*" + head, sol_text[start + 8:], re.I):
        n2 = x.group(2) or x.group(3)
        if n2 and n2 != num:
            end = start + 8 + x.start()
            break
    return sol_text[start:end]


def build_strategy(struct):
    s = dict(struct or {})
    clamp = lambda v, lo, hi, d: max(lo, min(hi, v)) if isinstance(v, int) and v > 0 else d
    minutes = clamp(s.get("duration_minutes"), 30, 360, 180)
    parts = []
    for p in (s.get("parts") or [])[:4]:
        p = dict(p)
        p["out_of"] = clamp(p.get("out_of"), 1, 12, 1)
        p["answer"] = min(clamp(p.get("answer"), 1, 12, 1), p["out_of"])
        p["points_each"] = clamp(p.get("points_each"), 1, 100, 0)
        parts.append(p)
    s["parts"], s["duration_minutes"] = parts, minutes
    n_q = sum(p["answer"] for p in parts) or 4
    per_q = max(5, int((minutes - 20) / n_q))
    plan = [{"t": 0, "what": "read_all", "min": 10}]
    t = 10
    for p in parts or [{"name": "", "answer": n_q}]:
        for _ in range(p["answer"]):
            plan.append({"t": t, "what": "question", "part": p.get("name", ""), "min": per_q})
            t += per_q
    plan.append({"t": t, "what": "review", "min": max(5, minutes - t)})
    return {"structure": s, "minutes": minutes, "plan": plan, "per_question": per_q}


SKIP_KEYS = {"kind", "source", "trust", "votes", "difficulty", "check_code", "correct", "answer_value", "id", "unit",
             "exam", "q", "number", "points", "has_solution", "t", "what", "min", "minutes", "per_question", "keywords",
             "duration_minutes", "answer", "out_of", "points_each", "exam_refs", "name", "part"}


def collect_strings(content):
    paths = []

    def walk(o, p):
        if isinstance(o, dict):
            for k, v in o.items():
                if k not in SKIP_KEYS:
                    walk(v, p + [k])
        elif isinstance(o, list):
            for i, v in enumerate(o):
                walk(v, p + [i])
        elif isinstance(o, str) and o.strip() and not re.fullmatch(r"[\d\s.,$\\{}()^_+\-*/=<>]*", o):
            paths.append(p)
    walk(content, [])
    return paths


def get_path(o, p):
    for k in p:
        o = o[k]
    return o


def set_path(o, p, v):
    for k in p[:-1]:
        o = o[k]
    o[p[-1]] = v


def match_library(units):
    lib = os.path.join(HERE, "library")
    found = {}
    if not os.path.isdir(lib):
        return found
    metas = [(n, json.load(open(os.path.join(lib, n, "meta.json"), encoding="utf-8")))
             for n in os.listdir(lib) if os.path.exists(os.path.join(lib, n, "meta.json"))]
    for u in units:
        text = " ".join([u.get("title", ""), " ".join(u.get("keywords", []))]).lower()
        best = None
        for name, meta in metas:
            hits = sum(1 for k in meta["keywords"] if k.lower() in text)
            if hits and (not best or hits > best[0]):
                best = (hits, name, meta)
        if best:
            found[u["id"]] = best
    return found


def build_app(out_dir, per_lang, main_lang, content_en, name):
    shell = open(os.path.join(HERE, "app_template.html"), encoding="utf-8").read()
    os.makedirs(out_dir, exist_ok=True)
    vend = os.path.join(HERE, "vendor", "katex")
    if os.path.isdir(vend):
        shutil.copytree(vend, os.path.join(out_dir, "vendor", "katex"), dirs_exist_ok=True)
    videos = {}
    for uid, (_, lib_name, meta) in match_library(content_en["units"]).items():
        os.makedirs(os.path.join(out_dir, "videos"), exist_ok=True)
        shutil.copy(os.path.join(HERE, "library", lib_name, meta["file"]), os.path.join(out_dir, "videos", meta["file"]))
        videos[uid] = {"src": "videos/" + meta["file"], "chapters": meta["chapters"], "pauses": meta.get("pauses", [])}
    data = {"name": name, "mainLang": main_lang, "langs": list(per_lang), "content": per_lang, "videos": videos,
            "builtAt": time.strftime("%Y-%m-%d %H:%M"), "generator": f"LearnLume {VERSION}"}
    blob = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    page = shell.replace("/*__LEARNLUME_DATA__*/null", blob)
    path = os.path.join(out_dir, "index.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(page)
    return path


def main():
    ap = argparse.ArgumentParser(description="LearnLume - offline study app builder")
    ap.add_argument("--job", default=os.path.join(HERE, "jobs", "demo"))
    ap.add_argument("--name", default="My course")
    ap.add_argument("--langs", default="he", help="comma list: he,en,ar,ru,es,fr")
    ap.add_argument("--mode", default="full", choices=list(MODES))
    ap.add_argument("--max-units", type=int, default=0)
    ap.add_argument("--max-exams", type=int, default=None)
    ap.add_argument("--ocr-threshold", type=float, default=None)
    ap.add_argument("--no-ocr", action="store_true")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--mock", action="store_true")
    ap.add_argument("--workers", type=int, default=6, help="Claude calls at the same time")
    ap.add_argument("--backend", choices=["api", "local"], default=None, help="default: the Studio setting, else api")
    ap.add_argument("--models", choices=list(PRESETS), default=None, help="which Claude models (api only)")
    a = ap.parse_args()
    b = Builder(a)
    for f in ("error.txt", "error.json"):
        try:
            os.remove(os.path.join(b.out, f))
        except OSError:
            pass
    if not a.no_browser:
        try:
            import webbrowser
            b.prog.write()
            webbrowser.open("file:///" + os.path.join(b.out, "progress.html").replace("\\", "/"))
        except Exception:
            pass
    try:
        path = b.run()
        print("\n\nDone:", path)
        if not a.no_browser:
            try:
                import webbrowser
                webbrowser.open("file:///" + path.replace("\\", "/"))
            except Exception:
                pass
    except ApiError as e:  # something the user can fix (key, credit) or wait out: a short message, no traceback
        with open(os.path.join(b.out, "error.json"), "w", encoding="utf-8") as f:
            json.dump({"code": e.code, "detail": e.detail}, f, ensure_ascii=False)
        with open(os.path.join(b.out, "error.txt"), "w", encoding="utf-8") as f:
            f.write(f"Claude API: {e.code}" + (f" ({e.detail})" if e.detail else "") + "\n")
        b.prog.state = "error"
        b.prog.note = "שגיאה - ראה error.txt"
        b.prog.write()
        print(f"\n\nStopped: Claude API {e.code} {e.detail}".rstrip(), file=sys.stderr)
        sys.exit(2)
    except BaseException:
        import traceback
        with open(os.path.join(b.out, "error.txt"), "w", encoding="utf-8") as f:
            f.write(traceback.format_exc())
        b.prog.state = "error"
        b.prog.note = "שגיאה - ראה error.txt"
        b.prog.write()
        raise
    finally:
        b.llm.stop()


if __name__ == "__main__":
    main()
