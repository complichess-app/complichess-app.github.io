# -*- coding: utf-8 -*-
"""
LearnLume Studio - the window where you drop PDFs and get a study app.
Runs only on this computer (127.0.0.1). Claude (or the local model) writes the app while it builds; the finished
app works offline. Only pages from this Studio may talk to it: other web sites open in the browser cannot.
"""
import json, os, re, subprocess, sys, threading, time, urllib.parse, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

import learnlume as engine

HERE = os.path.dirname(os.path.abspath(__file__))
JOBS = os.path.join(HERE, "jobs")
PORT = 8740
RUNNING = {}
HOSTS = {f"127.0.0.1:{PORT}", f"localhost:{PORT}"}
ORIGINS = {"http://" + h for h in HOSTS}
MAX_UPLOAD = 1 << 30
LANGS = set(engine.LANG_NAMES)

# Claude: about 25 seconds per call, 6 calls at a time
SEC_PER_CALL, WORKERS = 25, 6
# the local model on a normal CPU, measured on a 12-thread laptop (tokens per second)
GEN_TPS, PROMPT_TPS = 6.5, 37.0
RESERVED = {"con", "prn", "aux", "nul"} | {f"com{i}" for i in range(1, 10)} | {f"lpt{i}" for i in range(1, 10)}


def slug(s):
    s = re.sub(r"[^\w֐-׿\- ]+", "", s, flags=re.U).strip().replace(" ", "-")
    return (s or "course")[:40] + "-" + time.strftime("%m%d%H%M%S")


def safe_name(n):
    """a plain file name for this folder: no path, no characters Windows refuses, the extension kept"""
    n = os.path.basename(str(n).replace("\\", "/"))
    n = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", n).strip(" .")
    stem, ext = os.path.splitext(n)
    if stem.lower() in RESERVED:
        stem = "_" + stem
    ext = ext[:10]
    n = (stem[:150 - len(ext)] + ext).strip(" .")
    return n or "file.pdf"


def job_dir(jid):
    """the folder of an existing job; anything that is not a plain job id is refused"""
    if not isinstance(jid, str) or not re.fullmatch(r"[\w\-]{1,80}", jid) or not os.path.isdir(os.path.join(JOBS, jid)):
        raise LookupError(jid)
    return os.path.join(JOBS, jid)


def extract_pdfs(data, low, dest):
    """take only the PDF files out of a zip / tar archive (no paths, no other files)"""
    import io, tarfile, zipfile
    names = []

    def put(fname, blob):
        n = safe_name(fname)
        if not n.lower().endswith(".pdf"):
            n += ".pdf"
        base, i = n, 1
        while os.path.exists(os.path.join(dest, n)):
            n = f"{os.path.splitext(base)[0]}_{i}.pdf"
            i += 1
        with open(os.path.join(dest, n), "wb") as f:
            f.write(blob)
        names.append(n)
    if low.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                if info.filename.lower().endswith(".pdf") and not info.is_dir() and info.file_size < 300 * 2**20:
                    put(info.filename, z.read(info))
    else:
        with tarfile.open(fileobj=io.BytesIO(data)) as t:
            for m in t.getmembers():
                if m.isfile() and m.name.lower().endswith(".pdf") and m.size < 300 * 2**20:
                    put(m.name, t.extractfile(m).read())
    return names


def job_info(jid):
    d = os.path.join(JOBS, jid)
    meta = {}
    try:
        meta = json.load(open(os.path.join(d, "job.json"), encoding="utf-8"))
    except Exception:
        pass
    prog = {}
    try:
        prog = json.load(open(os.path.join(d, "output", "progress.json"), encoding="utf-8"))
    except Exception:
        pass
    inp = os.path.join(d, "input")
    files = sorted(os.listdir(inp)) if os.path.isdir(inp) else []
    err, code = "", ""
    ep = os.path.join(d, "output", "error.txt")
    if os.path.exists(ep):
        err = open(ep, encoding="utf-8").read()[-1500:]
    try:
        code = json.load(open(os.path.join(d, "output", "error.json"), encoding="utf-8")).get("code", "")
    except Exception:
        pass
    running = jid in RUNNING and RUNNING[jid].poll() is None
    state = prog.get("state") or ("new" if not prog else "stopped")
    if state == "running" and not running:
        state = "stopped"
    return {"id": jid, **meta, "files": files, "progress": prog, "state": state, "running": running, "error": err,
            "error_code": code, "has_app": os.path.exists(os.path.join(d, "output", "index.html"))}


def preset():
    p = engine.load_settings().get("preset")
    return p if p in engine.PRESETS else engine.DEFAULT_PRESET


def config():
    """what the settings card shows. The key itself never leaves this process: only whether there is one and
    its last 4 characters."""
    k, where = engine.key_source()
    return {"backend": engine.backend_choice(), "preset": preset(),
            "key": {"saved": bool(k), "last4": k[-4:] if k else "", "where": where},
            "key_file": engine.KEY_FILE,
            "presets": {n: {t: engine.MODEL_NAMES.get(m, m) for t, m in p.items()} for n, p in engine.PRESETS.items()},
            "local_ready": bool(engine.find_server() and engine.local_model("text"))}


def estimate(jid, mode, langs, backend, models):
    """minutes (and dollars with Claude) for a build, from the page count"""
    try:
        import pymupdf
    except Exception:
        return None
    inp = os.path.join(JOBS, jid, "input")
    pages = exams = 0
    for f in os.listdir(inp):
        if f.lower().endswith(".pdf"):
            try:
                n = len(pymupdf.open(os.path.join(inp, f)))
            except Exception:
                continue
            pages += n
            if re.search(r"exam|בחינ|מבחן", f.lower()):
                exams += 1
    full = mode == "full"
    if backend == "local":
        units = min(14 if full else 6, max(3, pages // 25))
        ppu = 8 if full else 4
        calls_tokens = units * (ppu / 2 * 700 + 1500 + (2 if full else 1) * 2000 + (8 if full else 4) * (2 * 200 + 120) + (1200 if full else 600) + 900 + 900)
        ex = min(exams, 5 if full else 2) * 8 * 2400  # ~8 questions, a long explanation each
        base = (calls_tokens + ex) * 1.15  # retries and verification votes
        other = [l for l in langs if l != "en"]
        gen = base * 1.7 if len(langs) == 1 and other else base + base * 1.9 * len(other)
        ocr = min(pages, units * ppu + min(exams, 5 if full else 2) * 15) * 0.5 * (900 / GEN_TPS + 1100 / PROMPT_TPS)
        minutes = (gen / GEN_TPS + gen * 3 / PROMPT_TPS + ocr) / 60
        return {"pages": pages, "units": units, "minutes": round(minutes), "cost": None}
    units = min(14 if full else 6, max(3, pages // 25))
    ppu = 14 if full else 6
    ex_q = min(exams, 6 if full else 2) * 6
    # (calls, input tokens, output tokens) per tier; output includes Claude's thinking
    mid = (units * (ppu / 4 + 1 + (2 if full else 1) + 3) + ex_q * 0.2 + min(pages, units * ppu) * 0.3,
           units * (ppu / 4 * 7000 + 4000 * 6) + min(pages, units * ppu) * 0.3 * 1800, units * (ppu / 4 * 1500 + 6000) * 1.4)
    top = (units * 2 + ex_q, (units * 2 + ex_q) * 5000, (units * 2 + ex_q) * 2500 * 1.6)
    fast = (units * (8 if full else 4) * 2, units * (8 if full else 4) * 2 * 300, units * (8 if full else 4) * 2 * 250 * 1.3)
    tr = max(0, len(langs) - (1 if langs else 0))
    mid = (mid[0] + tr * units * 4, mid[1] + tr * units * 12000, mid[2] + tr * units * 9000)
    chosen = engine.PRESETS.get(models) or engine.PRESETS[engine.DEFAULT_PRESET]
    cost = sum(t[1] * engine.PRICE[chosen[k]][0] / 1e6 + t[2] * engine.PRICE[chosen[k]][1] / 1e6
               for k, t in (("mid", mid), ("top", top), ("fast", fast)))
    calls = mid[0] + top[0] + fast[0]
    minutes = max(2, calls * SEC_PER_CALL / WORKERS / 60)
    return {"pages": pages, "units": units, "minutes": round(minutes), "cost": round(cost, 1)}


def clean_meta(data, meta=None):
    meta = dict(meta or {})
    if isinstance(data.get("name"), str) and data["name"].strip():
        meta["name"] = data["name"].strip()[:120]
    if isinstance(data.get("langs"), list):
        ls = [l for l in data["langs"] if l in LANGS]
        if ls:
            meta["langs"] = ls
    if data.get("mode") in ("quick", "full"):
        meta["mode"] = data["mode"]
    return meta


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.end_headers()
        self.wfile.write(body)

    def allowed(self, write=False):
        """only this Studio's own pages: the right Host (no DNS rebinding), no other site's Origin, and for every
        change the X-LearnLume header, which a page on another site cannot add without a CORS preflight we refuse"""
        if self.headers.get("Host", "") not in HOSTS:
            return False
        origin = self.headers.get("Origin")
        if origin is not None and origin not in ORIGINS:
            return False
        if self.headers.get("Sec-Fetch-Site", "same-origin") not in ("same-origin", "none"):
            return False
        if write and (origin is None or self.headers.get("X-LearnLume") != "1"):
            return False
        return True

    def q(self):
        return dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))

    def body(self):
        n = int(self.headers.get("Content-Length", 0) or 0)
        if n > MAX_UPLOAD:
            raise OverflowError
        return self.rfile.read(n) if n else b""

    def jbody(self):
        try:
            d = json.loads(self.body() or b"{}")
            return d if isinstance(d, dict) else {}
        except ValueError:
            return {}

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except (LookupError, KeyError):
            self.send(404, {"error": "job"})
        except OverflowError:
            self.send(413, {"error": "too big"})

    def do_OPTIONS(self):
        self.send(403, {"error": "forbidden"})

    def do_GET(self):
        if not self.allowed():
            return self.send(403, "forbidden", "text/plain")
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self.send(200, open(os.path.join(HERE, "studio.html"), "rb").read(), "text/html; charset=utf-8")
        if path == "/api/jobs":
            ids = sorted(os.listdir(JOBS), reverse=True) if os.path.isdir(JOBS) else []
            return self.send(200, [job_info(j) for j in ids if os.path.isdir(os.path.join(JOBS, j))])
        if path == "/api/job":
            jid = self.q()["job"]
            job_dir(jid)
            return self.send(200, job_info(jid))
        if path == "/api/estimate":
            q = self.q()
            job_dir(q["job"])
            langs = [l for l in q.get("langs", "he").split(",") if l in LANGS] or ["he"]
            return self.send(200, estimate(q["job"], q.get("mode", "full"), langs, engine.backend_choice(), preset()) or {})
        if path == "/api/config":
            return self.send(200, config())
        if path.startswith("/jobs/"):  # serve the built apps (only what is inside a job's output folder)
            rel = urllib.parse.unquote(path[len("/jobs/"):])
            parts = [p for p in re.split(r"[\\/]+", rel) if p]
            root = os.path.realpath(JOBS)
            full = os.path.realpath(os.path.join(root, *parts)) if parts else root
            try:
                inside = os.path.commonpath([os.path.normcase(full), os.path.normcase(root)]) == os.path.normcase(root)
            except ValueError:
                inside = False
            if not inside or len(parts) < 3 or parts[1] != "output" or ".." in parts or not os.path.isfile(full):
                return self.send(404, "not found", "text/plain")
            ext = os.path.splitext(full)[1].lower()
            ctype = {".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".mp4": "video/mp4",
                     ".woff2": "font/woff2", ".json": "application/json", ".png": "image/png"}.get(ext, "application/octet-stream")
            return self.send(200, open(full, "rb").read(), ctype)
        self.send(404, "not found", "text/plain")

    def do_POST(self):
        if not self.allowed(write=True):
            return self.send(403, {"error": "forbidden"})
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/new":
            meta = clean_meta(self.jbody(), {"name": "My course", "langs": ["he"], "mode": "full"})
            jid = slug(meta["name"])
            os.makedirs(os.path.join(JOBS, jid, "input"), exist_ok=True)
            meta["created"] = time.strftime("%Y-%m-%d %H:%M")
            json.dump(meta, open(os.path.join(JOBS, jid, "job.json"), "w", encoding="utf-8"), ensure_ascii=False)
            return self.send(200, {"id": jid})
        if path == "/api/settings":
            p = os.path.join(job_dir(self.q()["job"]), "job.json")
            meta = clean_meta(self.jbody(), json.load(open(p, encoding="utf-8")))
            json.dump(meta, open(p, "w", encoding="utf-8"), ensure_ascii=False)
            return self.send(200, {"ok": True})
        if path == "/api/start":
            jid = self.q()["job"]
            d = job_dir(jid)
            if jid in RUNNING and RUNNING[jid].poll() is None:
                return self.send(200, {"ok": True, "already": True})
            backend = engine.backend_choice()
            mock = bool(os.environ.get("LEARNLUME_MOCK"))
            if backend == "api" and not mock and not engine.api_key():
                return self.send(400, {"error": "no_key"})
            meta = json.load(open(os.path.join(d, "job.json"), encoding="utf-8"))
            args = [sys.executable, os.path.join(HERE, "learnlume.py"), "--job", d,
                    "--name", meta["name"], "--langs", ",".join(meta["langs"]), "--mode", meta["mode"], "--no-browser",
                    "--backend", backend]
            if backend == "api":
                args += ["--models", preset()]
            if mock:
                args.append("--mock")
            log = open(os.path.join(d, "build.log"), "w", encoding="utf-8")
            RUNNING[jid] = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, cwd=HERE,
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return self.send(200, {"ok": True})
        if path == "/api/config":
            data, kw = self.jbody(), {}
            if data.get("backend") in ("api", "local"):
                kw["backend"] = data["backend"]
            if data.get("preset") in engine.PRESETS:
                kw["preset"] = data["preset"]
            if kw:
                engine.save_settings(**kw)
            return self.send(200, config())
        if path == "/api/key":  # saved in the user's profile; sent only to api.anthropic.com
            k = str(self.jbody().get("key") or "").strip()
            if not engine.KEY_RE.fullmatch(k):
                return self.send(400, {"error": "format"})
            engine.save_key(k)
            engine.save_settings(backend="api")
            return self.send(200, {"saved": True, "last4": k[-4:]})
        if path == "/api/key/remove":
            engine.remove_key()
            return self.send(200, config())
        if path == "/api/key/test":
            k = str(self.jbody().get("key") or "").strip()
            if k and not engine.KEY_RE.fullmatch(k):
                return self.send(200, {"result": "format"})
            k = k or engine.api_key()
            return self.send(200, {"result": engine.ClaudeLLM.test_key(k) if k else "no_key"})
        if path == "/api/stop":
            jid = self.q()["job"]
            job_dir(jid)
            p = RUNNING.get(jid)
            if p and p.poll() is None:
                p.terminate()
            return self.send(200, {"ok": True})
        if path == "/api/folder":
            d = os.path.join(job_dir(self.q()["job"]), "output")
            if hasattr(os, "startfile") and os.path.isdir(d):
                os.startfile(d)
            return self.send(200, {"ok": True})
        self.send(404, {"error": "unknown"})

    def do_PUT(self):
        if not self.allowed(write=True):
            return self.send(403, {"error": "forbidden"})
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/upload":
            q = self.q()
            name = safe_name(q["name"])
            low = name.lower()
            d = os.path.join(job_dir(q["job"]), "input")
            os.makedirs(d, exist_ok=True)
            data = self.body()
            if low.endswith(".pdf"):
                with open(os.path.join(d, name), "wb") as f:
                    f.write(data)
                return self.send(200, {"ok": True, "names": [name]})
            if low.endswith((".zip", ".tar", ".tar.gz", ".tgz")):
                return self.send(200, {"ok": True, "names": extract_pdfs(data, low, d)})
            return self.send(400, {"error": "PDF / ZIP / TAR only"})
        self.send(404, {"error": "unknown"})


def main():
    os.makedirs(JOBS, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    url = f"http://127.0.0.1:{PORT}/"
    print(f"LearnLume {engine.VERSION} Studio is running: {url}\nKeep this window open while LearnLume works. Close it to stop.")
    if "--no-browser" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
