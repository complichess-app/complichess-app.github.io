@echo off
chcp 65001 >nul
title LearnLume Studio - keep this window open
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
  echo Python is not installed. Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
  pause
  exit /b
)
echo Preparing LearnLume 0.3...
%PY% -m pip install --user --quiet --disable-pip-version-check pymupdf sympy
echo.
echo LearnLume Studio opens in your browser.
echo Keep this window open while LearnLume builds. Close it to stop.
echo.
%PY% studio.py
pause
