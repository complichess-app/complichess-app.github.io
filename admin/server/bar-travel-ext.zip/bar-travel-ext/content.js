// Bridge between Barusik's admin page and this extension. Only the admin page loads it.
(() => {
  const VERSION = chrome.runtime.getManifest().version;
  const hello = () => window.postMessage({ src: 'bt-ext', type: 'hello', version: VERSION }, location.origin);
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== location.origin) return;
    const m = e.data;
    if (!m || m.src !== 'bt-page') return;
    if (m.type === 'ping') { hello(); return; }
    if (m.type !== 'job' || !m.id) return;
    chrome.runtime.sendMessage({ type: 'job', job: m.job }, (res) => {
      const err = chrome.runtime.lastError;
      window.postMessage({ src: 'bt-ext', type: 'result', id: m.id, ok: !err && res && res.ok, data: res && res.data, error: err ? err.message : res && res.error }, location.origin);
    });
  });
  hello();
  document.addEventListener('DOMContentLoaded', hello);
})();
