// Bar Lvovski Travel — runs customer searches in Bar's own logged-in BeAgent, inside his Chrome.
// Jobs arrive only from Barusik's server page (via content.js). Every job is checked and turned into a BeAgent
// results address here, so a job can never send the browser anywhere else.
'use strict';
const MARKUP = 1.12;
const BASE = 'https://travel.beagent.online';
const API = 'https://book-api.travelor.com/api';

// ---------- the worker window (minimized) ----------
async function workerWindow() {
  const { winId } = await chrome.storage.session.get('winId');
  if (winId) { try { const w = await chrome.windows.get(winId); if (w) return w.id; } catch {} }
  const w = await chrome.windows.create({ url: BASE + '/he', state: 'minimized', focused: false });
  await chrome.storage.session.set({ winId: w.id, apiTab: w.tabs && w.tabs[0] ? w.tabs[0].id : null });
  return w.id;
}
async function apiTab() {
  const winId = await workerWindow();
  let { apiTab: id } = await chrome.storage.session.get('apiTab');
  if (id) { try { const t = await chrome.tabs.get(id); if (t && t.windowId === winId && /^https:\/\/travel\.beagent\.online\//.test(t.url || t.pendingUrl || '')) return t.id; } catch {} }
  const t = await chrome.tabs.create({ windowId: winId, url: BASE + '/he', active: true });
  await chrome.storage.session.set({ apiTab: t.id });
  await waitLoaded(t.id);
  return t.id;
}
function waitLoaded(tabId, ms = 30000) {
  return new Promise((resolve) => {
    const done = () => { chrome.tabs.onUpdated.removeListener(fn); clearTimeout(t); resolve(); };
    const fn = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const t = setTimeout(done, ms);
    chrome.tabs.onUpdated.addListener(fn);
    chrome.tabs.get(tabId).then((tab) => { if (tab.status === 'complete') done(); }).catch(done);
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const isLogin = (url) => { try { return /(login|sign-?in|auth|register)/i.test(new URL(url).pathname); } catch { return false; } };

// ---------- BeAgent's own API headers (seen when BeAgent's site talks to its API; kept only in this browser's memory) ----------
chrome.webRequest.onSendHeaders.addListener((d) => {
  if (d.tabId < 0) return;
  const keep = {};
  for (const h of d.requestHeaders || []) if (/^(authorization|accept-language|x-[\w-]+|content-language)$/i.test(h.name)) keep[h.name.toLowerCase()] = h.value;
  if (keep.authorization) chrome.storage.session.set({ apiHeaders: keep });
}, { urls: ['https://book-api.travelor.com/*'] }, ['requestHeaders', 'extraHeaders']);

async function api(method, path, body) {
  let { apiHeaders } = await chrome.storage.session.get('apiHeaders');
  let tab = await apiTab();
  if (!apiHeaders) { await chrome.tabs.reload(tab); await waitLoaded(tab); await sleep(4000); ({ apiHeaders } = await chrome.storage.session.get('apiHeaders')); }
  if (!apiHeaders) throw new Error('no-login');
  const [r] = await chrome.scripting.executeScript({
    target: { tabId: tab }, world: 'MAIN',
    func: async (url, method, headers, body) => {
      const h = { ...headers, accept: 'application/json, text/plain, */*' };
      if (body) h['content-type'] = 'application/json';
      const res = await fetch(url, { method, headers: h, body: body ? JSON.stringify(body) : undefined });
      return { status: res.status, json: res.ok ? await res.json() : null };
    },
    args: [API + path, method, apiHeaders, body || null],
  });
  const out = r && r.result;
  if (!out) throw new Error('api-failed');
  if (out.status === 401) { await chrome.storage.session.remove('apiHeaders'); throw new Error('no-login'); }
  if (!out.json) throw new Error('api-' + out.status);
  return out.json;
}
const meta = () => ({ PageUrl: BASE + '/he', Langunge: 'he', Device: 2, Currency: 5, TimeStamp: new Date().toISOString(), NewSite: true, DeviceIP: null });

async function suggest(q) {
  const text = String(q.q || '').trim().slice(0, 60);
  const map = (j) => (j.data || []).slice(0, 12).map((x) => ({ title: x.title, value: x.value, sub: x.subTitle || '' }));
  const geo = async (type) => {
    if (text.length < 2) return type === 'packages' ? map(await api('GET', '/geo/packages/recommended?lang=he')) : [];
    return map(await api('GET', `/geo/${type}/autocomplete?query=${encodeURIComponent(text)}&lang=he`));
  };
  if (q.kind === 'flights') return geo('flights');
  if (q.kind === 'packages' || q.kind === 'tours') return geo('packages');
  if (q.kind === 'tickets') return geo('tickets');
  if (/^cars-(country|city|station)$/.test(q.kind)) {
    const t = q.kind === 'cars-country' ? 1 : q.kind === 'cars-city' ? 2 : 3;
    const dr = { requestType: t };
    if (t >= 2) { if (!q.country) return []; dr.pickUpCountry = { name: String(q.country).slice(0, 60) }; }
    if (t === 3) { if (!q.city) return []; dr.pickUpCity = { name: String(q.city).slice(0, 60) }; }
    const j = await api('POST', '/cars/Destinations', { destinationRequest: dr, ...meta(), driverNationality: 'IL' });
    const d = (j && j.destinationResponse) || {};
    if (t === 1) return (d.countries || []).filter((x) => x.name).map((x) => ({ title: x.name, value: x.name }));
    if (t === 2) return (d.cities || []).filter((x) => x.name).map((x) => ({ title: x.name, value: x.name }));
    return (d.stations || []).filter((x) => x.name).map((x) => ({ title: x.name, value: String(x.stationId) }));
  }
  throw new Error('bad-request');
}

const DATE = /^\d{4}-\d{2}-\d{2}$/;
async function packageDates(q) {
  const code = String(q.code || '').toUpperCase();
  if (!/^[A-Z]{3}$/.test(code)) throw new Error('bad-request');
  const dep = q.dep && DATE.test(q.dep) ? q.dep : null;
  const j = await api('POST', '/Packages/Calendar', { CalendarRequest: { SelectedDeparture: dep, DestinationCode: code, PackageFeature: null }, FromDate: null, ToDate: null, ...meta() });
  const deps = (j && j.calendarResponse && j.calendarResponse.departureDates) || [];
  const fix = (d) => ({ date: String(d.date || d).slice(0, 10), price: d.minPrice ? Math.round(d.minPrice * MARKUP) : null });
  let out = dep ? ((deps.find((d) => String(d.date).slice(0, 10) === dep) || deps[0] || {}).returnDates || []).map(fix) : deps.map(fix);
  const today = new Date().toISOString().slice(0, 10);
  return out.filter((d) => DATE.test(d.date) && d.date >= today);
}

// ---------- searches ----------
function okDate(s) {
  if (!DATE.test(s || '')) return false;
  const t = Date.parse(s + 'T12:00:00Z'), now = Date.now();
  return t > now - 86400000 && t < now + 400 * 86400000;
}
function int(v, lo, hi) { const n = parseInt(v, 10); return Number.isFinite(n) && n >= lo && n <= hi ? n : null; }
const clean = (s, n = 60) => String(s || '').replace(/[<>"]/g, '').trim().slice(0, n);
function buildUrl(q) {
  const U = (p, params) => { const u = new URL(BASE + p); for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v); return u.toString(); };
  if (q.kind === 'flights') {
    const from = String(q.from || '').toUpperCase(), to = String(q.to || '').toUpperCase();
    if (!/^[A-Z]{3}$/.test(from) || !/^[A-Z]{3}$/.test(to) || from === to || !okDate(q.dep)) return null;
    const adults = int(q.adults, 1, 9); if (!adults) return null;
    const p = { departureCodes: from, arrivalCodes: to, departureDates: q.dep };
    if (q.ret) { if (!okDate(q.ret) || q.ret < q.dep) return null; p.arrivalDates = q.ret; p.routeType = '2'; } else p.routeType = '1';
    p.pax = '1_' + adults; p.flightClass = String(int(q.cls || 1, 1, 4) || 1);
    return { url: U('/he/flights/results', p), cta: 'בחירת כרטיסים' };
  }
  if (q.kind === 'hotels') {
    const lat = Number(q.lat), lng = Number(q.lng);
    if (!(Math.abs(lat) <= 90 && Math.abs(lng) <= 180) || !okDate(q.in) || !okDate(q.out) || q.out <= q.in) return null;
    const adults = int(q.adults, 1, 6); if (!adults) return null;
    return { url: U('/he/hotels/place/x/results', { check_in: q.in, check_out: q.out, guests: Array(adults).fill('a').join(','), country: 'IL', currency: 'ILS',
      radius: String(int(q.radius, 500, 20000) || 3000), latitude: lat.toFixed(6), longitude: lng.toFixed(6), take: '48', sort_by: 'popular', sort: 'desc' }), cta: 'הצג חדרים' };
  }
  if (q.kind === 'cars') {
    const country = clean(q.country), city = clean(q.city), station = String(q.station || '');
    if (!country || !city || !/^\d{1,12}$/.test(station) || !okDate(q.from) || !okDate(q.to) || q.to < q.from) return null;
    const tm = (t) => (/^([01]\d|2[0-3]):(00|30)$/.test(t || '') ? t : '12:00');
    return { url: U('/he/cars/results', { pickUpCountry: country, pickUpCity: city, pickUpStation: station, dropOffCountry: country, dropOffCity: city, dropOffStation: station,
      driverNationality: 'IL', fromDate: q.from, toDate: q.to, fromTime: tm(q.fromTime), toTime: tm(q.toTime), driverAge: String(int(q.age, 18, 99) || 30) }), cta: 'לפרטי השכרה' };
  }
  if (q.kind === 'packages') {
    const code = String(q.code || '').toUpperCase(); const adults = int(q.adults, 1, 6);
    if (!/^[A-Z]{3}$/.test(code) || !okDate(q.from) || !okDate(q.to) || q.to <= q.from || !adults) return null;
    return { url: U('/he/packages/results', { destinationCode: code, fromDate: q.from, toDate: q.to, rooms: '1_' + adults, packageFeature: '0' }), cta: 'בחירת חדרים' };
  }
  if (q.kind === 'tours') {
    const code = String(q.code || '').toUpperCase();
    if (!/^[A-Z]{3}$/.test(code) || !/^\d{4}-\d{2}$/.test(q.month || '')) return null;
    return { url: U('/he/trips/results', { destinationCode: code, fromDate: q.month + '-01', category: '0' }), cta: 'לפרטי טיול' };
  }
  if (q.kind === 'tickets') {
    const target = String(q.target || '');
    if (!/^\d{1,9}_\d{1,3}$/.test(target) || !okDate(q.from) || !okDate(q.to) || q.to < q.from) return null;
    return { url: U('/he/event-tickets/results', { target, fromDate: q.from, toDate: q.to, destinationQuery: '' }), cta: 'בחירה כרטיסים' };
  }
  return null;
}

// Anything that could reveal Bar's agent side is dropped from the results.
const PRIVATE = /עמלה|עמלת|commission|נטו|net price|רווח|profit|סוכן|agent|ארנק|wallet|יתרה|balance|קרדיט|credit/i;
const SKIP = /^(פירוט המחיר|מידע חשוב|בחירת כרטיסים|בחירה כרטיסים|הצג חדרים|בחירת חדרים|לפרטי השכרה|לפרטי טיול|הצג במפה|מדיניות דלק|שעות טיסה|בסיס אירוח|כבודה|\d|₪)$/;
const money = (n) => '₪' + Math.round(n).toLocaleString('en-US');
const markup = (line) => line
  .replace(/₪\s?([\d,]+(?:\.\d+)?)/g, (_, v) => money(parseFloat(v.replace(/,/g, '')) * MARKUP))
  .replace(/([\d,]+(?:\.\d+)?)\s?₪/g, (_, v) => money(parseFloat(v.replace(/,/g, '')) * MARKUP));
function tidy(lines) {
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    let l = lines[i];
    if (l === '₪' && /^[\d,]+$/.test(lines[i + 1] || '')) { l = '₪' + lines[i + 1]; i++; }
    if (/[:\-]$/.test(l) && lines[i + 1] && !/[:]$/.test(lines[i + 1]) && l.length < 20) { l = l + ' ' + lines[i + 1]; i++; }
    out.push(l);
  }
  return out;
}

// Runs inside the BeAgent results page.
function pageState(cta) {
  return {
    n: [...document.querySelectorAll('button,a')].filter((b) => (b.innerText || '').trim() === cta).length,
    none: /לא מצאנו|לא נמצאו|אין תוצאות|no results/i.test(document.body ? document.body.innerText : ''),
    url: location.href,
  };
}
function extract(cta) {
  const isCta = (b) => (b.innerText || '').trim() === cta;
  const btns = [...document.querySelectorAll('button,a')].filter((b) => isCta(b) && b.getClientRects().length > 0);
  const src = (i) => i.currentSrc || i.src || '';
  const bigImg = (el) => [...el.querySelectorAll('img')].find((i) => (i.naturalWidth || i.width) >= 150 && /^https:\/\//.test(src(i)));
  const bigCount = (el) => [...el.querySelectorAll('img')].filter((i) => (i.naturalWidth || i.width) >= 150 && /^https:\/\//.test(src(i))).length;
  const lines = (t) => t.split(/[\n\t]/).map((s) => s.trim()).filter(Boolean);
  const heads = new Map(); const out = []; const seen = new Set();
  for (const b of btns) {
    let row = b;
    while (row.parentElement && !(/₪/.test(row.innerText) && row.innerText.length > 40)) row = row.parentElement;
    if (!row || row === document.body) continue;
    let g = row, group = null;
    for (let k = 0; k < 9 && g && g !== document.body; k++) {
      if (bigImg(g)) { group = g; break; }
      const p = g.parentElement;
      if (!p || p === document.body || bigCount(p) > 1) break;
      g = p;
    }
    if (!group) {
      let c = row;
      while (c.parentElement && c.parentElement !== document.body && btns.filter((x) => c.parentElement.contains(x)).length === 1) c = c.parentElement;
      if (c !== row) group = c;
    }
    let head = [], img = null;
    if (group && group !== row) {
      if (!heads.has(group)) {
        const first = lines(row.innerText)[0] || '';
        const all = group.innerText; const idx = first ? all.indexOf(first) : -1;
        heads.set(group, lines(idx > 0 ? all.slice(0, idx) : ''));
      }
      head = heads.get(group); img = bigImg(group);
    } else if (group === row) img = bigImg(row);
    const rowLines = lines(row.innerText);
    const sig = head.join('|') + '#' + rowLines.join('|');
    if (seen.has(sig)) continue; seen.add(sig);
    const pick = (el) => [...el.querySelectorAll('img')].filter((i) => i !== img && /^https:\/\//.test(src(i))).map(src);
    let logos = pick(row); if (!logos.length && group) logos = pick(group);
    out.push({ head, rows: rowLines, img: img ? src(img) : null, logos: logos.slice(0, 3) });
    if (out.length >= 40) break;
  }
  return out;
}

let running = 0; const waiting = [];
const slot = () => new Promise((res) => { if (running < 2) { running++; res(); } else waiting.push(res); });
const free = () => { const n = waiting.shift(); if (n) n(); else running--; };

async function runSearch(q) {
  const target = buildUrl(q);
  if (!target) throw new Error('bad-request');
  await slot();
  const winId = await workerWindow();
  const tab = await chrome.tabs.create({ windowId: winId, url: target.url, active: false });
  try {
    const run = async (func, ...args) => { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args }); return r && r.result; };
    let last = -1, stable = 0;
    for (let i = 0; i < 60; i++) {
      await sleep(1000);
      let st; try { st = await run(pageState, target.cta); } catch { continue; }
      if (!st) continue;
      if (isLogin(st.url)) throw new Error('no-login');
      if (st.none && st.n === 0 && i > 5) break;
      if (st.n > 0 && st.n === last) { if (++stable >= 4) break; } else stable = 0;
      last = st.n;
    }
    for (let i = 0; i < 2; i++) { await run(() => scrollTo(0, document.body.scrollHeight)); await sleep(1500); }
    const raw = (await run(extract, target.cta)) || [];
    const results = raw.map((r) => {
      const head = tidy(r.head).filter((l) => !SKIP.test(l) && !PRIVATE.test(l) && !/₪|החל מ/.test(l) && !/^[\d,.\s]+$/.test(l) && l.length < 120);
      const rows = tidy(r.rows).filter((l) => !SKIP.test(l) && !PRIVATE.test(l) && l.length < 160).map(markup);
      const tot = rows.findIndex((l) => /סה.?כ/.test(l));
      const pm = (tot >= 0 ? rows.slice(tot).join(' ') : rows.join(' ')).match(/₪[\d,]+/);
      return { head, lines: rows, img: r.img, logos: r.logos, price: pm ? parseInt(pm[0].replace(/\D/g, ''), 10) : null };
    }).filter((r) => r.price);
    return { kind: q.kind, results, link: target.url, at: new Date().toISOString() };
  } finally { chrome.tabs.remove(tab.id).catch(() => {}); free(); }
}

// Is BeAgent logged in? (opens the worker window if needed)
async function start() {
  const tab = await apiTab();
  await chrome.tabs.reload(tab); await waitLoaded(tab); await sleep(3000);
  const t = await chrome.tabs.get(tab);
  return { loggedIn: !isLogin(t.url || '') };
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || m.type !== 'job' || !sender.tab) return;
  const j = m.job || {};
  (async () => {
    if (j.type === 'start') return start();
    if (j.type === 'login') { await chrome.tabs.create({ url: BASE + '/he', active: true }); return { opened: true }; }
    if (j.type === 'search') return runSearch(j.params || {});
    if (j.type === 'suggest') return suggest(j.params || {});
    if (j.type === 'pkgdates') return packageDates(j.params || {});
    throw new Error('bad-request');
  })().then((data) => reply({ ok: true, data }), (e) => reply({ ok: false, error: String(e && e.message || e).slice(0, 200) }));
  return true;
});
