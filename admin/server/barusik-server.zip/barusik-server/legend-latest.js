/* Loads the newest bot and poker brain from barusik.com, so a fix there needs only a refresh of the PokerNow page.
   The copies inside the extension (loaded just before this) keep playing if the site can't be reached. © Bar Lvovski. */
(async () => {
  const v = Math.floor(Date.now() / 120000);   // at most two minutes behind the site
  const get = (u) => fetch(u + '?v=' + v, { cache: 'no-store' }).then((r) => (r.ok ? r.text() : Promise.reject(new Error(String(r.status)))));
  try {
    const [engine, bot] = await Promise.all([get('https://barusik.com/poker/engine.js'), get('https://barusik.com/admin/server/legend-pokernow.js')]);
    if (!/function legend\(/.test(engine) || !/__legend/.test(bot)) return;
    const was = window.Poker;
    try { (0, eval)(engine); (0, eval)(bot); } catch (_e) { window.Poker = was; }
  } catch (_e) { /* offline: the built-in copy plays */ }
})();
