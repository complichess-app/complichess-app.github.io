// The admin pages' side of the bridge. Only barusik.com/admin/ gets it, and the page itself checks that the user is the admin.
(() => {
  document.documentElement.dataset.btExt = chrome.runtime.getManifest().version;
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.src !== 'bt-page-ext') return;
    try { chrome.runtime.sendMessage({ to: 'bg', msg: e.data }).catch(() => {}); } catch {}
  });
  chrome.runtime.onMessage.addListener((m) => {
    if (m && m.to === 'page') window.postMessage({ ...m.msg, src: 'bt-hands-ext' }, location.origin);
  });
})();
