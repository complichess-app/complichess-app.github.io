// The BeAgent tab's side of the bridge: hands.js <-> the extension.
(() => {
  const send = (msg) => { try { chrome.runtime.sendMessage({ to: 'server', msg }).catch(() => {}); } catch {} };
  // the login page: nothing can run until Bar signs in, so tell the server page
  if (location.hostname.startsWith('accounts.')) {
    send({ type: 'need-login' });
    setInterval(() => send({ type: 'need-login' }), 5000);
    return;
  }
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.src !== 'bt-hands-ext') return;
    send(e.data);
  });
  chrome.runtime.onMessage.addListener((m) => {
    if (m && m.to === 'hands') window.postMessage({ ...m.msg, src: 'bt-page-ext' }, location.origin);
  });
})();
