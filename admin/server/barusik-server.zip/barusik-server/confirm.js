// The approval window for a withdrawal. Only Bar's click here lets the wallet pay; web pages can't reach this window.
const k = new URLSearchParams(location.search).get('k') || '';
const $ = (id) => document.getElementById(id);
chrome.runtime.sendMessage({ to: 'confirm', k, get: true }, (d) => {
  if (!d) { $('msg').textContent = 'הבקשה כבר לא פתוחה.'; $('ok').disabled = true; return; }
  $('who').textContent = `משיכה #${d.id} · ${d.asset}`;
  $('amt').textContent = `${d.amount} ${d.asset}`;
  $('addr').textContent = d.address;
  if (d.asset === 'BTC') { $('pwBox').hidden = false; $('pw').focus(); } else $('ok').focus();
});
$('ok').onclick = () => {
  const password = $('pw').value;
  if (!$('pwBox').hidden && !password) { $('msg').textContent = 'צריך את סיסמת הארנק.'; return; }
  $('ok').disabled = true;
  chrome.runtime.sendMessage({ to: 'confirm', k, ok: true, password }, () => window.close());
};
$('no').onclick = () => chrome.runtime.sendMessage({ to: 'confirm', k, ok: false }, () => window.close());
addEventListener('keydown', (e) => { if (e.key === 'Escape') $('no').click(); });
