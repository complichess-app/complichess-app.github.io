// Tells hands.js that the extension carries its messages, so it needs no window of its own.
window.__btExt = true;
