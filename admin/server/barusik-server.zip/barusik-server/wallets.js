// The wallets on this computer: Wasabi (BTC) and monero-wallet-rpc (XMR), both on 127.0.0.1 only.
// Only the server page (barusik.com/admin/server/) may ask, only for the read-only methods below, and the RPC passwords stay in this
// extension's storage on this computer. Nothing here is ever sent to barusik.com.
// Money leaves only through payout(): the extension itself claims the withdrawal in the database (requested -> sending, once) and
// pays exactly the address and amount the database holds. A script on the page cannot choose where money goes.
const RPC_METHODS = {
  xmr: ['get_version', 'get_height', 'get_balance', 'create_address', 'get_transfers', 'validate_address'],
  btc: ['getstatus', 'getwalletinfo', 'getnewaddress', 'listunspentcoins', 'listcoins', 'gethistory'],
};
const SB_URL = 'https://iktmyrfbejtjsiehcrar.supabase.co', SB_KEY = 'sb_publishable_vEUqQPQSE0EG7YRnwNeAbg_PzViDO1a';
const DEFAULTS = { xmrUrl: 'http://127.0.0.1:18088/json_rpc', xmrUser: '', xmrPass: '', btcUrl: 'http://127.0.0.1:37128/', btcWallet: '', btcUser: '', btcPass: '' };
const localOnly = (u) => { try { const x = new URL(u); return x.protocol === 'http:' && (x.hostname === '127.0.0.1' || x.hostname === 'localhost') && !x.username && !x.password; } catch { return false; } };

// an error that certainly happened before anything was sent (the wallet answered "no", or we never asked it to pay)
class Sure extends Error { constructor(m) { super(m); this.sure = true; } }

// ---------- MD5, for monero-wallet-rpc's digest login ----------
function md5(str) {
  const b = new TextEncoder().encode(str), n = ((b.length + 8) >>> 6) + 1, w = new Uint32Array(n * 16);
  for (let i = 0; i < b.length; i++) w[i >> 2] |= b[i] << ((i % 4) * 8);
  w[b.length >> 2] |= 0x80 << ((b.length % 4) * 8); w[n * 16 - 2] = b.length * 8;
  const K = [], S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 2 ** 32) >>> 0;
  let [a0, b0, c0, d0] = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476];
  for (let o = 0; o < w.length; o += 16) {
    let [A, B, C, D] = [a0, b0, c0, d0];
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + K[i] + w[o + g]) >>> 0; A = D; D = C; C = B;
      const s = S[(i >> 4) * 4 + (i % 4)]; B = (B + ((F << s) | (F >>> (32 - s)))) >>> 0;
    }
    a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0; c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
  }
  return [a0, b0, c0, d0].map((x) => [0, 8, 16, 24].map((s) => ((x >>> s) & 255).toString(16).padStart(2, '0')).join('')).join('');
}

// monero-wallet-rpc may send one challenge per algorithm (MD5-sess and MD5); answer the plain MD5 one
function challenge(h) {
  const parts = h.split(/(?=\bDigest\s)/i).map((p) => p.trim()).filter(Boolean);
  const parse = (p) => { const o = {}; p.replace(/^Digest\s+/i, '').replace(/(\w+)=(?:"([^"]*)"|([^,\s]*))/g, (_, k, q, v) => { o[k.toLowerCase()] = q ?? v; }); return o; };
  const all = parts.map(parse);
  return all.find((c) => !c.algorithm || c.algorithm.toUpperCase() === 'MD5') || null;
}
const q = (s) => String(s).replace(/["\\]/g, (c) => '\\' + c);
async function digestFetch(url, body, user, pass) {
  const opts = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, credentials: 'omit', cache: 'no-store', redirect: 'error' };
  let r = await fetch(url, opts);
  if (r.status !== 401 || !user) return r;
  const c = challenge(r.headers.get('www-authenticate') || '');
  if (!c || !c.nonce) return r;
  const uri = new URL(url).pathname, qop = (c.qop || '').split(',').map((s) => s.trim()).includes('auth') ? 'auth' : '';
  const cnonce = [...crypto.getRandomValues(new Uint8Array(12))].map((x) => x.toString(16).padStart(2, '0')).join(''), nc = '00000001';
  const ha1 = md5(`${user}:${c.realm || ''}:${pass}`), ha2 = md5(`POST:${uri}`);
  const resp = qop ? md5(`${ha1}:${c.nonce}:${nc}:${cnonce}:${qop}:${ha2}`) : md5(`${ha1}:${c.nonce}:${ha2}`);
  let auth = `Digest username="${q(user)}", realm="${q(c.realm || '')}", nonce="${q(c.nonce)}", uri="${q(uri)}", algorithm=MD5, response="${resp}"`;
  if (qop) auth += `, qop=${qop}, nc=${nc}, cnonce="${cnonce}"`;
  if (c.opaque !== undefined) auth += `, opaque="${q(c.opaque)}"`;
  return fetch(url, { ...opts, headers: { ...opts.headers, Authorization: auth } });
}

// one call at a time per wallet: monero-wallet-rpc keeps one login nonce, so two calls in parallel would knock each other out
const lanes = { xmr: Promise.resolve(), btc: Promise.resolve() };
const inLane = (wallet, fn) => { const p = lanes[wallet].then(fn, fn); lanes[wallet] = p.catch(() => {}); return p; };

const cfg = async () => ({ ...DEFAULTS, ...(await chrome.storage.local.get('walletCfg')).walletCfg });
async function rawRpc(wallet, method, params) {
  const c = await cfg();
  const body = JSON.stringify({ jsonrpc: '2.0', id: '1', method, params: params ?? {} });
  return inLane(wallet, async () => {
    let r;
    if (wallet === 'xmr') {
      if (!localOnly(c.xmrUrl)) throw new Sure('xmr address must be 127.0.0.1');
      r = await digestFetch(c.xmrUrl, body, c.xmrUser, c.xmrPass);
      if (r.status === 401) { await r.text().catch(() => {}); r = await digestFetch(c.xmrUrl, body, c.xmrUser, c.xmrPass); }
    } else {
      if (!localOnly(c.btcUrl)) throw new Sure('btc address must be 127.0.0.1');
      const url = c.btcUrl.replace(/\/?$/, '/') + (c.btcWallet ? encodeURIComponent(c.btcWallet) : '');
      const headers = { 'Content-Type': 'application/json' };
      if (c.btcUser) headers.Authorization = 'Basic ' + btoa(String.fromCharCode(...new TextEncoder().encode(`${c.btcUser}:${c.btcPass}`)));
      r = await fetch(url, { method: 'POST', headers, body, credentials: 'omit', cache: 'no-store', redirect: 'error' });
    }
    if (r.status === 401 || r.status === 403) throw new Sure(`wallet login refused (http ${r.status})`);
    const text = await r.text();
    let j; try { j = JSON.parse(text); } catch { throw new Error(`wallet http ${r.status}`); }
    if (j && j.error) throw new Sure(String(j.error.message || j.error).slice(0, 200));
    return j.result;
  });
}

async function walletRpc(wallet, method, params) {
  if (!Object.hasOwn(RPC_METHODS, wallet) || !RPC_METHODS[wallet].includes(method)) throw new Sure('method not allowed');
  if (params != null && typeof params !== 'object') throw new Sure('bad params');
  return rawRpc(wallet, method, params);
}

// settings come from the server page, are kept here, and only "is it set" goes back
async function walletCfg(set) {
  const cur = await cfg();
  if (set) {
    for (const k of Object.keys(DEFAULTS)) {
      if (typeof set[k] !== 'string') continue;
      if (k.endsWith('Pass')) { if (set[k] !== '') cur[k] = set[k]; } else cur[k] = set[k].trim();
    }
    if (!localOnly(cur.xmrUrl) || !localOnly(cur.btcUrl)) throw new Sure('only 127.0.0.1 addresses');
    await chrome.storage.local.set({ walletCfg: cur });
  }
  return { xmrUrl: cur.xmrUrl, xmrUser: cur.xmrUser, xmrPass: !!cur.xmrPass, btcUrl: cur.btcUrl, btcWallet: cur.btcWallet, btcUser: cur.btcUser, btcPass: !!cur.btcPass };
}

// ---------- paying a withdrawal ----------
async function sbRpc(fn, args, token) {
  const r = await fetch(`${SB_URL}/rest/v1/rpc/${fn}`, {
    method: 'POST', credentials: 'omit', cache: 'no-store',
    headers: { 'Content-Type': 'application/json', apikey: SB_KEY, Authorization: 'Bearer ' + token },
    body: JSON.stringify(args),
  });
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Sure((j && j.message) || `database http ${r.status}`);
  return j;
}
const busyIds = new Set();
async function spent() { return (await chrome.storage.local.get({ walletSpent: [] })).walletSpent; }
async function markSpent(id) { const s = await spent(); if (!s.includes(id)) { s.push(id); await chrome.storage.local.set({ walletSpent: s.slice(-500) }); } }

// ---------- Bar's approval, in a window that belongs to the extension ----------
const asks = new Map();
function askBar(details) {
  return new Promise(async (resolve) => {
    const k = crypto.randomUUID();
    const done = (r) => { if (!asks.has(k)) return; const a = asks.get(k); asks.delete(k); clearTimeout(a.t); if (a.win) chrome.windows.remove(a.win).catch(() => {}); resolve(r); };
    asks.set(k, { details, done, t: setTimeout(() => done({ ok: false }), 180000) });
    try { const w = await chrome.windows.create({ url: chrome.runtime.getURL('confirm.html?k=' + k), type: 'popup', width: 440, height: 560, focused: true }); const a = asks.get(k); if (a) a.win = w.id; }
    catch { done({ ok: false }); }
  });
}
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || m.to !== 'confirm' || sender.id !== chrome.runtime.id || !(sender.url || '').startsWith(chrome.runtime.getURL('confirm.html'))) return;
  const a = asks.get(String(m.k || ''));
  if (m.get) { reply(a ? a.details : null); return; }
  if (a) { a.win = null; a.done({ ok: !!m.ok, password: typeof m.password === 'string' ? m.password : '' }); }
  reply(true);
});
chrome.windows.onRemoved.addListener((id) => { for (const a of asks.values()) if (a.win === id) { a.win = null; a.done({ ok: false }); } });
const human = (atomic, asset) => { const d = asset === 'BTC' ? 8 : 12, s = String(atomic).padStart(d + 1, '0'); return (s.slice(0, -d) + '.' + s.slice(-d)).replace(/\.?0+$/, ''); };

async function payout({ wid, token, coins }) {
  const id = Number(wid);
  if (!Number.isSafeInteger(id) || id <= 0 || typeof token !== 'string' || token.length > 4000) throw new Sure('bad request');
  if (busyIds.has(id)) throw new Sure('already sending');
  busyIds.add(id);
  let claimed = false, marked = false;
  try {
    // a withdrawal this extension already tried to pay is never paid again from here: if it is unclear whether it left, check the wallet and use "sent manually"
    if ((await spent()).includes(id)) throw new Error('this extension already sent (or tried to send) this withdrawal. Check the wallet; if nothing left, send it from the wallet app and mark it manually');
    const w = await sbRpc('cw_admin_claim', { p_id: id }, token);
    claimed = true;
    if (!w || Number(w.id) !== id || w.status !== 'sending' || !/^[1-9][0-9]*$/.test(String(w.atomic || ''))) throw new Sure('the database did not hand over this withdrawal');
    const atomic = Number(w.atomic), address = String(w.address);
    if (!Number.isSafeInteger(atomic)) throw new Sure('amount too large');
    if (w.asset === 'XMR') {
      if (!/^[48][1-9A-HJ-NP-Za-km-z]{94}$/.test(address)) throw new Sure('bad address');
      const v = await rawRpc('xmr', 'validate_address', { address, any_net_type: false, allow_openalias: false });
      if (!v || !v.valid || v.integrated || (v.nettype && v.nettype !== 'mainnet')) throw new Sure('the wallet says this is not a valid mainnet address');
      const yes = await askBar({ id, asset: 'XMR', amount: human(atomic, 'XMR'), address });
      if (!yes.ok) throw new Sure('Bar did not approve it');
      await markSpent(id); marked = true;
      const r = await rawRpc('xmr', 'transfer', { destinations: [{ amount: atomic, address }], account_index: 0, priority: 0, get_tx_key: true });
      return { txid: String(r && r.tx_hash || ''), asset: 'XMR', atomic: String(atomic) };
    }
    if (w.asset === 'BTC') {
      if (!/^(bc1[02-9ac-hj-np-z]{11,87}|[13][1-9A-HJ-NP-Za-km-z]{25,34})$/.test(address)) throw new Sure('bad address');
      const pick = (Array.isArray(coins) ? coins : []).slice(0, 200).map((c) => ({ transactionid: String(c && c.transactionid || ''), index: Number(c && c.index) }))
        .filter((c) => /^[0-9a-f]{64}$/i.test(c.transactionid) && Number.isSafeInteger(c.index) && c.index >= 0);
      if (!pick.length) throw new Sure('no coins chosen');
      const yes = await askBar({ id, asset: 'BTC', amount: human(atomic, 'BTC'), address });
      if (!yes.ok) throw new Sure('Bar did not approve it');
      if (!yes.password || yes.password.length > 500) throw new Sure('wallet password needed');
      await markSpent(id); marked = true;
      const r = await rawRpc('btc', 'send', { payments: [{ sendto: address, amount: atomic, label: 'barusik withdrawal ' + id }], coins: pick, feeTarget: 6, password: yes.password });
      return { txid: String(r && r.txid || ''), asset: 'BTC', atomic: String(atomic) };
    }
    throw new Sure('bad asset');
  } catch (e) {
    // the wallet refused before paying: this withdrawal may be tried again later
    if (e && e.sure) {
      if (marked) { const s = await spent(); const i = s.indexOf(id); if (i >= 0) { s.splice(i, 1); await chrome.storage.local.set({ walletSpent: s }); } }
      if (claimed) { await sbRpc('cw_admin_unclaim', { p_id: id, p_note: null }, token).catch(() => {}); e.message = 'not sent, back in the queue: ' + e.message; }
    }
    throw e;
  } finally { busyIds.delete(id); }
}

self.barusikWallets = { walletRpc, walletCfg, payout };
