// The wallets on this computer: Wasabi (BTC) and monero-wallet-rpc (XMR), both on 127.0.0.1 only.
// Only the server page (barusik.com/admin/server/) may ask, only for the methods below, and the RPC passwords stay in this
// extension's storage on this computer. Nothing here is ever sent to barusik.com or Supabase.
const RPC_METHODS = {
  xmr: ['get_version', 'get_height', 'get_balance', 'create_address', 'get_transfers', 'transfer', 'validate_address'],
  btc: ['getstatus', 'getwalletinfo', 'getnewaddress', 'listunspentcoins', 'listcoins', 'gethistory', 'send'],
};
const DEFAULTS = { xmrUrl: 'http://127.0.0.1:18088/json_rpc', xmrUser: '', xmrPass: '', btcUrl: 'http://127.0.0.1:37128/', btcWallet: '', btcUser: '', btcPass: '' };
const localOnly = (u) => { try { const x = new URL(u); return x.protocol === 'http:' && (x.hostname === '127.0.0.1' || x.hostname === 'localhost'); } catch { return false; } };

// ---------- MD5, for monero-wallet-rpc's digest login ----------
function md5(str) {
  const b = new TextEncoder().encode(str), n = ((b.length + 8) >>> 6) + 1, w = new Uint32Array(n * 16);
  for (let i = 0; i < b.length; i++) w[i >> 2] |= b[i] << ((i % 4) * 8);
  w[b.length >> 2] |= 0x80 << ((b.length % 4) * 8); w[n * 16 - 2] = b.length * 8;
  const K = [], S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 2 ** 32) >>> 0;
  let [a0, b0, c0, d0] = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476];
  for (let o = 0; o < w.length; o += 16) {
    let [A, B, C, D] = [a0, b0, c0, d0];
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + K[i] + w[o + g]) >>> 0; A = D; D = C; C = B;
      const s = S[(i >> 4) * 4 + (i % 4)]; B = (B + ((F << s) | (F >>> (32 - s)))) >>> 0;
    }
    a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0; c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
  }
  return [a0, b0, c0, d0].map((x) => [0, 8, 16, 24].map((s) => ((x >>> s) & 255).toString(16).padStart(2, '0')).join('')).join('');
}
async function digestFetch(url, body, user, pass) {
  const opts = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body };
  let r = await fetch(url, opts);
  if (r.status !== 401 || !user) return r;
  const h = r.headers.get('www-authenticate') || '';
  const get = (k) => (h.match(new RegExp(k + '="?([^",]+)"?')) || [])[1] || '';
  const realm = get('realm'), nonce = get('nonce'), qop = /auth/.test(get('qop')) ? 'auth' : '', u = new URL(url), uri = u.pathname;
  const cnonce = crypto.getRandomValues(new Uint32Array(2)).join(''), nc = '00000001';
  const ha1 = md5(`${user}:${realm}:${pass}`), ha2 = md5(`POST:${uri}`);
  const resp = qop ? md5(`${ha1}:${nonce}:${nc}:${cnonce}:${qop}:${ha2}`) : md5(`${ha1}:${nonce}:${ha2}`);
  const auth = `Digest username="${user}", realm="${realm}", nonce="${nonce}", uri="${uri}", algorithm=MD5, response="${resp}"` + (qop ? `, qop=${qop}, nc=${nc}, cnonce="${cnonce}"` : '');
  return fetch(url, { ...opts, headers: { ...opts.headers, Authorization: auth } });
}

async function walletRpc(wallet, method, params) {
  if (!RPC_METHODS[wallet] || !RPC_METHODS[wallet].includes(method)) throw new Error('method not allowed');
  const c = { ...DEFAULTS, ...(await chrome.storage.local.get('walletCfg')).walletCfg };
  const body = JSON.stringify({ jsonrpc: '2.0', id: '1', method, params: params ?? {} });
  let r;
  if (wallet === 'xmr') {
    if (!localOnly(c.xmrUrl)) throw new Error('xmr address must be 127.0.0.1');
    r = await digestFetch(c.xmrUrl, body, c.xmrUser, c.xmrPass);
  } else {
    if (!localOnly(c.btcUrl)) throw new Error('btc address must be 127.0.0.1');
    const url = c.btcUrl.replace(/\/?$/, '/') + (c.btcWallet ? encodeURIComponent(c.btcWallet) : '');
    const headers = { 'Content-Type': 'application/json' };
    if (c.btcUser) headers.Authorization = 'Basic ' + btoa(`${c.btcUser}:${c.btcPass}`);
    r = await fetch(url, { method: 'POST', headers, body });
  }
  const text = await r.text();
  let j; try { j = JSON.parse(text); } catch { throw new Error(`wallet http ${r.status}`); }
  if (j.error) throw new Error(String(j.error.message || j.error).slice(0, 200));
  return j.result;
}

// settings come from the server page, are kept here, and only "is it set" goes back
async function walletCfg(set) {
  const cur = { ...DEFAULTS, ...(await chrome.storage.local.get('walletCfg')).walletCfg };
  if (set) {
    for (const k of Object.keys(DEFAULTS)) if (typeof set[k] === 'string' && (set[k] !== '' || !k.endsWith('Pass'))) cur[k] = set[k].trim();
    if (!localOnly(cur.xmrUrl) || !localOnly(cur.btcUrl)) throw new Error('only 127.0.0.1 addresses');
    await chrome.storage.local.set({ walletCfg: cur });
  }
  return { xmrUrl: cur.xmrUrl, xmrUser: cur.xmrUser, xmrPass: !!cur.xmrPass, btcUrl: cur.btcUrl, btcWallet: cur.btcWallet, btcUser: cur.btcUser, btcPass: !!cur.btcPass };
}

self.barusikWallets = { walletRpc, walletCfg };
