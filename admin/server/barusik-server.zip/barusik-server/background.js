// Keeps the two tabs the travel server needs (BeAgent and the server page) open, and carries messages between them.
const BEAGENT = 'https://travel.beagent.online/he';
const SERVER = 'https://barusik.com/admin/server/';
const BE_TABS = ['https://travel.beagent.online/*', 'https://accounts.beagent.online/*'];

const state = async () => (await chrome.storage.local.get({ wanted: false, auto: true }));
const handsTab = async () => (await chrome.storage.session.get({ hands: null })).hands;

async function serverTabs() { return chrome.tabs.query({ url: SERVER + '*' }); }
async function beTabs() { return chrome.tabs.query({ url: BE_TABS }); }
const keep = (id) => chrome.tabs.update(id, { pinned: true, autoDiscardable: false }).catch(() => {});

// open whatever is missing, in the background, pinned and protected from Chrome's memory saver
async function ensure(opts = {}) {
  let be = await beTabs();
  if (!be.length) be = [await chrome.tabs.create({ url: BEAGENT, active: false, pinned: true })];
  await keep((be.find((t) => t.pinned) || be[0]).id);
  let sv = await serverTabs();
  // one server page at a time: two would argue about the green light
  const me = opts.keepTab ?? (sv.find((t) => t.pinned) || sv[0] || {}).id;
  for (const t of sv) if (t.id !== me) chrome.tabs.remove(t.id).catch(() => {});
  if (me === undefined) sv = [await chrome.tabs.create({ url: SERVER + '?auto=1', active: false, pinned: true })];
  await keep(me ?? sv[0].id);
  if (opts.focusBe) { const t = be.find((x) => x.pinned) || be[0]; await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); }
}

chrome.runtime.onMessage.addListener((m, sender) => {
  (async () => {
    if (m.to === 'server') {
      // from a BeAgent tab: only one of them does the work, the first one that says hello
      const id = sender.tab && sender.tab.id;
      let chosen = await handsTab();
      if (chosen !== null) { try { const t = await chrome.tabs.get(chosen); if (!/^https:\/\/(travel|accounts)\.beagent\.online\//.test(t.url || '')) chosen = null; } catch { chosen = null; } }
      if (chosen === null) { chosen = id; await chrome.storage.session.set({ hands: id }); }
      if (chosen !== id) return;
      for (const t of await serverTabs()) chrome.tabs.sendMessage(t.id, { to: 'page', msg: m.msg }).catch(() => {});
      return;
    }
    if (m.to !== 'bg') return;
    const msg = m.msg;
    if (msg.type === 'ensure') { await chrome.storage.local.set({ wanted: true }); await ensure({ keepTab: sender.tab && sender.tab.id }); return; }
    if (msg.type === 'focus-hands') { await ensure({ focusBe: true }); return; }
    if (msg.type === 'off') { await chrome.storage.local.set({ wanted: false }); }
    if (msg.type === 'auto') { await chrome.storage.local.set({ auto: !!msg.on }); return; }
    // anything else goes on to the BeAgent tab
    const chosen = await handsTab();
    const tabs = chosen !== null ? [{ id: chosen }] : await chrome.tabs.query({ url: 'https://travel.beagent.online/*' });
    for (const t of tabs) chrome.tabs.sendMessage(t.id, { to: 'hands', msg }).catch(() => {});
  })();
});

// when a tab that was doing the work goes away, the next hello takes over
chrome.tabs.onRemoved.addListener(async (id) => { if (await handsTab() === id) await chrome.storage.session.set({ hands: null }); });

// starts with Chrome, and comes back by itself if one of the tabs was closed by accident
chrome.runtime.onStartup.addListener(async () => { const s = await state(); if (s.auto && s.wanted) await ensure(); });
chrome.alarms.create('watch', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async () => { const s = await state(); if (s.wanted) await ensure(); });

// after installing or updating: tabs that are already open need a reload to get the new scripts
chrome.runtime.onInstalled.addListener(async () => {
  for (const t of await chrome.tabs.query({ url: ['https://barusik.com/admin/*', 'https://travel.beagent.online/*'] })) chrome.tabs.reload(t.id).catch(() => {});
});

chrome.action.onClicked.addListener(async () => {
  const sv = await serverTabs();
  if (sv.length) { await chrome.tabs.update(sv[0].id, { active: true }); await chrome.windows.update(sv[0].windowId, { focused: true }); }
  else await chrome.tabs.create({ url: SERVER + '?go=1' });
});
